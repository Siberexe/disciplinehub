#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║     TERMİNAL PSİKOLOJİK SİMÜLASYON MOTORU — VARLIK ÜRETICI               ║
║     generate_assets.py  |  Versiyon: 4.2.1  |  @LonySoraz                 ║
╚══════════════════════════════════════════════════════════════════════════════╝

Kullanım:
    python generate_assets.py

Bu script aşağıdaki ses varlıklarını oluşturur:
  assets/tv_static.wav    — TV statik gürültüsü (0.6 saniye, beyaz gürültü)
  assets/tv_click.wav     — TV tıklama sesi (0.08 saniye, klik)
  assets/jumpscare.wav    — Jumpscare sesi (1.2 saniye, yüksek frekanslı patlama)

NOT: Lonu.mp3 ve horror_bgm.mp3 dosyaları bu script tarafından üretilmez.
     Kendi MP3 dosyalarınızı assets/ klasörüne koymanız gerekir.
     Ya da ffmpeg ile WAV → MP3 dönüşümü yapabilirsiniz.
"""

import os
import struct
import math
import random
import array
import wave
import subprocess
import sys

# ─── Sabitler ─────────────────────────────────────────────────────────────────

ASSETS_DIR   = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
SAMPLE_RATE  = 44100       # Hz
NUM_CHANNELS = 1           # Mono
SAMPLE_WIDTH = 2           # 16-bit


# ─── WAV Yardımcıları ────────────────────────────────────────────────────────

def _write_wav(filepath: str, samples: list, sample_rate: int = SAMPLE_RATE) -> None:
    """
    PCM örneklerini WAV dosyasına yazar.

    Args:
        filepath:    Hedef dosya yolu
        samples:     -32768 ile 32767 arası tam sayı listesi
        sample_rate: Örnekleme hızı (Hz)
    """
    with wave.open(filepath, "wb") as wf:
        wf.setnchannels(NUM_CHANNELS)
        wf.setsampwidth(SAMPLE_WIDTH)
        wf.setframerate(sample_rate)
        # array ile hızlı yazım
        packed = array.array("h", [max(-32768, min(32767, int(s))) for s in samples])
        wf.writeframes(packed.tobytes())

    size_kb = os.path.getsize(filepath) / 1024
    print(f"  ✓  {os.path.basename(filepath):30s}  ({size_kb:.1f} KB)")


def _sine_wave(freq: float, duration: float, amplitude: float = 0.5,
               sample_rate: int = SAMPLE_RATE) -> list:
    """Sinüs dalgası örnek listesi üretir"""
    num = int(sample_rate * duration)
    return [
        int(amplitude * 32767 * math.sin(2 * math.pi * freq * i / sample_rate))
        for i in range(num)
    ]


def _white_noise(duration: float, amplitude: float = 0.4,
                 sample_rate: int = SAMPLE_RATE) -> list:
    """Beyaz gürültü örnek listesi üretir"""
    num = int(sample_rate * duration)
    return [
        int(amplitude * 32767 * (random.random() * 2 - 1))
        for _ in range(num)
    ]


def _apply_envelope(samples: list, attack: float = 0.01,
                    decay: float = 0.1, sustain: float = 0.7,
                    release: float = 0.1) -> list:
    """
    ADSR zarfı uygular.
    attack, decay, sustain, release oranlar (0.0–1.0) cinsinden.
    """
    n = len(samples)
    a_end = int(n * attack)
    d_end = int(n * (attack + decay))
    r_start = int(n * (1.0 - release))

    result = []
    for i, s in enumerate(samples):
        if i < a_end:
            env = i / max(1, a_end)
        elif i < d_end:
            t = (i - a_end) / max(1, d_end - a_end)
            env = 1.0 - t * (1.0 - sustain)
        elif i < r_start:
            env = sustain
        else:
            t = (i - r_start) / max(1, n - r_start)
            env = sustain * (1.0 - t)
        result.append(int(s * env))

    return result


def _mix(*sample_lists) -> list:
    """Birden fazla örnek listesini karıştırır (normalize eder)"""
    max_len = max(len(sl) for sl in sample_lists)
    result = []
    for i in range(max_len):
        val = sum(sl[i] if i < len(sl) else 0 for sl in sample_lists)
        result.append(val // len(sample_lists))
    return result


def _fade_in(samples: list, fade_samples: int) -> list:
    """Giriş solma efekti"""
    result = list(samples)
    for i in range(min(fade_samples, len(result))):
        result[i] = int(result[i] * (i / fade_samples))
    return result


def _fade_out(samples: list, fade_samples: int) -> list:
    """Çıkış solma efekti"""
    result = list(samples)
    n = len(result)
    for i in range(min(fade_samples, n)):
        result[n - 1 - i] = int(result[n - 1 - i] * (i / fade_samples))
    return result


# ─── Ses Oluşturucular ───────────────────────────────────────────────────────

def generate_tv_static() -> None:
    """
    TV statik gürültüsü (tv_static.wav).

    Beyaz gürültü + düşük frekanslı titreşim karışımı.
    Eski televizyon statik sesine benzer.
    Süre: 0.7 saniye
    """
    path = os.path.join(ASSETS_DIR, "tv_static.wav")
    sr   = SAMPLE_RATE
    dur  = 0.7

    # Beyaz gürültü katmanı (yüksek frekans)
    noise_high = _white_noise(dur, amplitude=0.35, sample_rate=sr)

    # Alçak frekans gürültü (titreşim)
    noise_low  = _white_noise(dur, amplitude=0.15, sample_rate=sr)
    # Alçak geçişli filtre (basit ortalama)
    filtered = []
    win = 20
    for i in range(len(noise_low)):
        start = max(0, i - win)
        filtered.append(int(sum(noise_low[start:i+1]) / (i - start + 1)))
    noise_low = filtered

    # Ek: 50Hz titreşim (eski TV bobini)
    hum = _sine_wave(50, dur, amplitude=0.05, sample_rate=sr)

    # Karıştır
    samples = _mix(noise_high, noise_low, hum)

    # Kısa giriş/çıkış solma
    fade = int(sr * 0.03)
    samples = _fade_in(samples, fade)
    samples = _fade_out(samples, fade)

    _write_wav(path, samples, sr)


def generate_tv_click() -> None:
    """
    TV kanal değiştirme tıklama sesi (tv_click.wav).

    Kısa, yüksek frekanslı mekanik klik + hızlı söner.
    Süre: 0.09 saniye
    """
    path = os.path.join(ASSETS_DIR, "tv_click.wav")
    sr   = SAMPLE_RATE
    dur  = 0.09

    # Ana klik — yüksek frekans patlama
    click_freq = 3000.0
    click = _sine_wave(click_freq, dur, amplitude=0.7, sample_rate=sr)

    # Harmonik (doğallık için)
    harm  = _sine_wave(click_freq * 2, dur, amplitude=0.2, sample_rate=sr)

    # Çok kısa beyaz gürültü patlama (mekanik his)
    noise = _white_noise(dur, amplitude=0.3, sample_rate=sr)

    # Karıştır
    samples = _mix(click, harm, noise)

    # ADSR zarfı — çok kısa atak, uzun release
    samples = _apply_envelope(samples, attack=0.01, decay=0.30,
                               sustain=0.1, release=0.50)

    _write_wav(path, samples, sr)


def generate_jumpscare() -> None:
    """
    Jumpscare ses efekti (jumpscare.wav).

    Yüksek frekanslı bant patlama + düşen ton + statik gürültü.
    Psikolojik etki için optimize edilmiş frekans aralığı.
    Süre: 1.3 saniye
    """
    path = os.path.join(ASSETS_DIR, "jumpscare.wav")
    sr   = SAMPLE_RATE

    # ── Bölüm 1: Ani çığlık (0–0.2s) ──
    shriek_dur = 0.2
    shriek = []
    num = int(sr * shriek_dur)
    for i in range(num):
        # Frekans hızla yükselir: 400Hz → 2000Hz
        t = i / sr
        freq = 400 + (2000 - 400) * (i / num)
        val = int(0.85 * 32767 * math.sin(2 * math.pi * freq * t))
        shriek.append(val)

    # ── Bölüm 2: Statik patlama (0.2–0.5s) ──
    burst_dur = 0.3
    burst = _white_noise(burst_dur, amplitude=0.75, sample_rate=sr)
    # Envelope: ani atak, hızlı söner
    burst = _apply_envelope(burst, attack=0.01, decay=0.5, sustain=0.3, release=0.4)

    # ── Bölüm 3: Düşen ton (0.5–0.9s) ──
    fall_dur = 0.4
    fall = []
    num_f = int(sr * fall_dur)
    for i in range(num_f):
        t = i / sr
        freq = 1500 * math.exp(-3 * i / num_f)  # Üstel düşüş
        freq = max(60, freq)
        val = int(0.5 * 32767 * math.sin(2 * math.pi * freq * t))
        fall.append(val)

    # ── Bölüm 4: Son statik (0.9–1.3s) ──
    end_dur = 0.4
    end_noise = _white_noise(end_dur, amplitude=0.2, sample_rate=sr)
    end_noise = _fade_out(end_noise, int(sr * 0.3))

    # Tüm bölümleri birleştir
    all_samples = shriek + burst + fall + end_noise

    # Genel fade-in
    all_samples = _fade_in(all_samples, int(sr * 0.005))

    _write_wav(path, all_samples, sr)


def generate_placeholder_mp3(filename: str, description: str) -> None:
    """
    MP3 için WAV placeholder oluşturur (ffmpeg varsa MP3'e dönüştürür).

    Args:
        filename:    Oluşturulacak dosyanın adı (örn: "Lonu.mp3")
        description: Açıklama metni
    """
    # Önce WAV oluştur
    wav_path = os.path.join(ASSETS_DIR, filename.replace(".mp3", "_placeholder.wav"))
    mp3_path = os.path.join(ASSETS_DIR, filename)

    # Basit 440Hz sinüs tonu (3 saniye) — placeholder
    sr  = SAMPLE_RATE
    dur = 3.0
    samples = _sine_wave(440, dur, amplitude=0.3, sample_rate=sr)

    # Fade in/out
    fade = int(sr * 0.3)
    samples = _fade_in(samples, fade)
    samples = _fade_out(samples, fade)

    _write_wav(wav_path, samples, sr)

    # ffmpeg ile MP3'e dönüştür (varsa)
    try:
        import shutil
        if shutil.which("ffmpeg"):
            result = subprocess.run(
                ["ffmpeg", "-y", "-i", wav_path, "-ab", "128k", mp3_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=30,
            )
            if result.returncode == 0:
                os.remove(wav_path)
                print(f"  ✓  {filename:30s}  (placeholder MP3 — kendi müziğinizle değiştirin)")
            else:
                # MP3 dönüşümü başarısız — WAV'ı MP3 olarak yeniden adlandır
                os.rename(wav_path, mp3_path)
                print(f"  ⚠  {filename:30s}  (placeholder WAV→MP3 yeniden adlandırıldı)")
        else:
            # ffmpeg yok — WAV dosyasını MP3 adıyla kaydet
            os.rename(wav_path, mp3_path)
            print(f"  ⚠  {filename:30s}  (ffmpeg bulunamadı, WAV kaydedildi — MP3 dönüşümü el ile yapın)")
    except Exception as e:
        # Hata — WAV'ı taşı
        try:
            if os.path.exists(wav_path):
                os.rename(wav_path, mp3_path)
        except Exception:
            pass
        print(f"  ⚠  {filename:30s}  (dönüştürme hatası: {e})")


# ─── Ana Fonksiyon ────────────────────────────────────────────────────────────

def main() -> None:
    """Tüm ses varlıklarını oluşturur"""

    print("\n" + "═" * 60)
    print("  TERMİNAL PSİKOLOJİK SİMÜLASYON MOTORU")
    print("  Ses Varlığı Üreticisi")
    print("═" * 60)

    # assets/ dizini oluştur
    os.makedirs(ASSETS_DIR, exist_ok=True)
    print(f"\n  Hedef dizin: {ASSETS_DIR}\n")

    # ── WAV dosyaları ──
    print("  WAV Efektleri Oluşturuluyor:")
    print("  " + "─" * 50)

    generate_tv_static()
    generate_tv_click()
    generate_jumpscare()

    print()

    # ── MP3 placeholder ──
    print("  MP3 Placeholder Oluşturuluyor:")
    print("  " + "─" * 50)

    for fname, desc in [
        ("Lonu.mp3",       "Arka plan müziği"),
        ("horror_bgm.mp3", "Korku arka planı"),
    ]:
        fpath = os.path.join(ASSETS_DIR, fname)
        if os.path.isfile(fpath) and os.path.getsize(fpath) > 10000:
            size_kb = os.path.getsize(fpath) / 1024
            print(f"  ✓  {fname:30s}  (mevcut dosya korundu — {size_kb:.0f} KB)")
        else:
            generate_placeholder_mp3(fname, desc)

    print("\n" + "═" * 60)
    print("  TAMAMLANDI!")
    print()
    print("  ÖNEMLİ: Lonu.mp3 ve horror_bgm.mp3 dosyalarını")
    print("  kendi müzik dosyalarınızla değiştirin.")
    print("  Mevcut dosyalar sadece birer placeholder (440Hz ton).")
    print()
    print("  Çalıştırmak için:")
    print("    python main.py")
    print("═" * 60 + "\n")


if __name__ == "__main__":
    main()
