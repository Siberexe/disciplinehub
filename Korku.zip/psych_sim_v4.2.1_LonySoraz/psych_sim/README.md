# TERMİNAL PSİKOLOJİK SİMÜLASYON MOTORU
### Versiyon 4.2.1 — @LonySoraz

---

## 📁 Proje Yapısı

```
psych_sim/
├── main.py               ← Ana giriş noktası
├── audio_engine.py       ← Ses yönetimi (AudioManager)
├── scene_engine.py       ← Sahne motoru (30 + 40 sahne)
├── glitch_engine.py      ← Glitch efektleri (CRT simülasyonu)
├── visual_elements.py    ← Görsel elementler (göz, beyin, vb.)
├── generate_assets.py    ← Ses varlığı üreticisi
├── requirements.txt      ← Python bağımlılıkları
├── README.md             ← Bu dosya
└── assets/
    ├── Lonu.mp3          ← Normal mod arka plan müziği [KENDİ DOSYANIZI EKLEYIN]
    ├── horror_bgm.mp3    ← CTRL+C modu müziği [KENDİ DOSYANIZI EKLEYIN]
    ├── jumpscare.wav     ← Jumpscare efekti [generate_assets.py ile oluşturulur]
    ├── tv_static.wav     ← TV statik geçiş [generate_assets.py ile oluşturulur]
    └── tv_click.wav      ← TV tıklama sesi [generate_assets.py ile oluşturulur]
```

---

## ⚡ Hızlı Başlangıç

### Linux (Debian/Ubuntu)
```bash
sudo apt update
sudo apt install mpv python3
cd psych_sim
python generate_assets.py   # Ses efektlerini oluştur
python main.py               # Çalıştır
```

### Termux (Android)
```bash
pkg update
pkg install mpv python
cd psych_sim
python generate_assets.py
python main.py
```

---

## 🎵 Müzik Dosyaları

`Lonu.mp3` ve `horror_bgm.mp3` kendi müzik dosyalarınızı koymanız gerekir:

```bash
# Örnek: Kendi dosyalarınızı kopyalayın
cp /path/to/your/music.mp3 assets/Lonu.mp3
cp /path/to/horror/music.mp3 assets/horror_bgm.mp3
```

Placeholder (440Hz test tonu) oluşturmak için:
```bash
python generate_assets.py
```

---

## 🎮 Kontroller

| Tuş        | Eylem                         |
|------------|-------------------------------|
| ENTER      | Giriş ekranından devam        |
| CTRL+C     | Korku modu tetikle (40 sahne) |
| (otomatik) | Normal mod 30 sahnede biter   |

---

## 🔊 Ses Kuralları

| Durum              | Ses                            |
|--------------------|--------------------------------|
| Normal mod         | Lonu.mp3 (döngü)               |
| CTRL+C tetiklenince| Lonu.mp3 TAMAMEN DURUR         |
| CTRL+C modu        | horror_bgm.mp3 (döngü)         |
| Jumpscare anları   | jumpscare.wav                  |
| Sahne geçişi       | tv_static.wav + tv_click.wav   |
| Program bitti      | TÜM SES DURUR — mpv sonlandı   |

---

## 🖥️ Teknik Gereksinimler

- **Python**: 3.7+
- **Ses**: mpv (önerilir) veya ffplay
- **Terminal**: 80×24 minimum (daha büyük önerilir)
- **İşletim Sistemi**: Linux, Termux (Android), macOS

---

## 🏗️ Modül Açıklamaları

### `audio_engine.py`
- `AudioManager` sınıfı
- `play_music(filepath, loop, volume)` — arka plan müziği
- `stop_music()` — müziği tamamen durdur
- `play_sfx(filepath, volume)` — efekt çal (eş zamanlı)
- `stop_all()` — her şeyi durdur, mpv sonlandır

### `scene_engine.py`
- `Scene` dataclass — sahne verisi
- `SceneManager` — sahne sırası ve çalıştırma
- `TransitionManager` — TV statik geçiş animasyonu
- `SceneTimingController` — 10–15 saniye rastgele süre

### `glitch_engine.py`
- `GlitchEngine` sınıfı
- `crt_noise()` — CRT ekran gürültüsü
- `static_flash()` — TV statik kar flaşı
- `glitch_text()` — metin bozma
- `screen_break()` — ekran kırılması
- `scanline_effect()` — tarama çizgisi
- `horizontal_tear()` — yatay yırtılma
- `random_flicker()` — rastgele titreme
- `frame_drop()` — frame düşürme

### `visual_elements.py`
- `VisualElements` sınıfı
- `rotating_triangle_eye()` — dönen üçgen göz
- `fake_system_logs()` — sahte sistem günlükleri
- `falling_numbers()` — düşen sayılar (Matrix)
- `brain_ascii()` — beyin ASCII animasyonu
- `illusion_dots()` — illüzyon nokta efekti
- `fake_scan()` — sahte tarama çubuğu

---

## 🎬 Sahne Akışı

### Normal Mod (30 Sahne)
```
Sahne 1–5   : Sistem başlatma (sakin, gerçekçi)
Sahne 6–10  : Veri tespiti (merak uyandıran)
Sahne 11–15 : Kişisel veri toplama (gerilim)
Sahne 16–20 : Saldırı eskalasyonu (panik)
Sahne 21–25 : Psikolojik baskı (korku)
Sahne 26–29 : Maksimum gerilim
Sahne 30    : AÇIKLAMA — Bu bir simülasyondu!
```

### CTRL+C Modu (40 Sahne)
```
Sahne 1–5   : CTRL+C tepkisi (sert)
Sahne 6–15  : Kimlik ve takip teması
Sahne 16–25 : Psikolojik baskı (maksimum)
Sahne 26–35 : Derin kaos
Sahne 36–39 : Çözülme ve umut
Sahne 40    : AÇIKLAMA — Psikolojik deneyim bitti
```

---

## ⚠️ Sorun Giderme

**"ses çalmıyor"**
```bash
pkg install mpv   # Termux
sudo apt install mpv  # Linux
```

**"terminal çok küçük"**
Terminal boyutunu 80×24'ten büyük yapın.

**"ModuleNotFoundError"**
```bash
pip install windows-curses  # Sadece Windows
```

**"assets/ bulunamadı"**
```bash
mkdir assets
python generate_assets.py
```

---

*Powered by @LonySoraz*
