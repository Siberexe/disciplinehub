#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║     TERMİNAL PSİKOLOJİK SİMÜLASYON MOTORU — GÖRSEL ELEMENTLER             ║
║     visual_elements.py  |  Versiyon: 4.2.1  |  @LonySoraz                 ║
╚══════════════════════════════════════════════════════════════════════════════╝

Psikolojik etki yaratan terminal görsel elementleri:
  • Dönen üçgen göz sembolü (Illuminati / all-seeing eye)
  • Sahte sistem günlükleri (fake system logs)
  • Düşen sayılar (Matrix tarzı)
  • Beyin ASCII animasyonu
  • İllüzyon merkez nokta efekti
  • Sahte tarama mesajları
  • Yanıp sönen uyarı blokları

Tüm elementler sahne içinde çağrılabilir.
curses penceresi ve frame sayacı argüman olarak alınır.
"""

import curses
import random
import time
import math
from typing import List, Tuple, Optional

# ─── Sabitler ─────────────────────────────────────────────────────────────────

# Sahte sistem günlüğü mesajları (Türkçe)
FAKE_LOG_POOL = [
    "[SYS  ] Çekirdek belleği başlatılıyor...          OK",
    "[NET  ] Ağ arayüzü eth0 bağlandı                  OK",
    "[SEC  ] Güvenlik duvarı kuralları yüklendi         OK",
    "[CPU  ] Frekans: 3.8GHz - Sıcaklık: 42°C          OK",
    "[MEM  ] RAM kullanımı: 2.1GB / 16GB               OK",
    "[DISK ] /dev/sda1 bağlandı                        OK",
    "[PROC ] İşlem tablosu taranıyor...               WARN",
    "[NET  ] Dış bağlantı tespit edildi: 185.220.1.xx WARN",
    "[SEC  ] Şifreleme modülü yüklendi                 OK",
    "[KERN ] syscall tablosu değiştirildi             CRIT",
    "[MEM  ] Beklenmeyen bellek erişimi               CRIT",
    "[NET  ] Gizli port açık: 0x1337                 WARN",
    "[IO   ] /proc/self/mem okunuyor...               WARN",
    "[SEC  ] SSH anahtarı ele geçirildi              CRIT",
    "[CPU  ] Kripto madencilik süreci tespit edildi  CRIT",
    "[DISK ] /etc/shadow okunamıyor                  CRIT",
    "[NET  ] VPN tüneli kesildi                      CRIT",
    "[SEC  ] Root yetkisi alındı                     CRIT",
    "[MEM  ] Stack overflow oluştu                   CRIT",
    "[KERN ] Çekirdek modülü yükleniyor...            ERR",
    "[SYS  ] Sistem saati değiştirildi               WARN",
    "[PROC ] /sbin/init değiştirildi                 CRIT",
    "[NET  ] Paket dinleme başlatıldı                CRIT",
    "[IO   ] Klavye girişi yakalanıyor               CRIT",
    "[SEC  ] Firewall devre dışı bırakıldı          CRIT",
    "[CPU  ] Anomalous instruction pointer           CRIT",
    "[MEM  ] Heap corruption detected               CRIT",
    "[NET  ] C2 sunucu bağlantısı kuruldu           CRIT",
    "[DISK ] Dosyalar şifreleniyor...               CRIT",
    "[KERN ] Kernel panic yaklaşıyor                CRIT",
]

# Sahte tarama mesajları
FAKE_SCAN_POOL = [
    "Sistem taranıyor...",
    "Güvenlik açıkları analiz ediliyor...",
    "Bellek haritası çıkarılıyor...",
    "Ağ trafiği izleniyor...",
    "Süreçler listeleniyor...",
    "Dosya sistemi tarıyor...",
    "Şifre hashları karşılaştırılıyor...",
    "Browser geçmişi okunuyor...",
    "SSH anahtarları aranıyor...",
    "Wi-Fi şifreleri çekiliyor...",
    "Konum verisi alınıyor...",
    "Kamera akışı başlatılıyor...",
    "Mikrofon dinleniyor...",
    "Kişisel veriler yükleniyor...",
    "Kimlik analizi yapılıyor...",
]

# Dönen üçgen göz ASCII çerçeveleri (8 kare animasyon)
EYE_FRAMES = [
    # Kare 0 — normal
    [
        "      /\\      ",
        "     /  \\     ",
        "    / ◉  \\    ",
        "   /______\\   ",
        "      ||      ",
        "   III III    ",
    ],
    # Kare 1 — sol yatık
    [
        "     /\\       ",
        "    /  \\      ",
        "   / ◉  \\     ",
        "  /______\\    ",
        "     ||       ",
        "  III III     ",
    ],
    # Kare 2 — merkez küçük
    [
        "       /\\     ",
        "      /  \\    ",
        "     / ◉  \\   ",
        "    /______\\  ",
        "       ||     ",
        "    III III   ",
    ],
    # Kare 3 — sağ yatık
    [
        "        /\\    ",
        "       /  \\   ",
        "      / ◉  \\  ",
        "     /______\\ ",
        "        ||    ",
        "     III III  ",
    ],
    # Kare 4 — büyük
    [
        "     /\\       ",
        "    /  \\      ",
        "   / ◎  \\     ",
        "  /________\\  ",
        "      ||      ",
        "   IIIIIII    ",
    ],
    # Kare 5 — göz yarı kapalı
    [
        "      /\\      ",
        "     /--\\     ",
        "    / ◉  \\    ",
        "   /______\\   ",
        "      ||      ",
        "   III III    ",
    ],
    # Kare 6 — parlayan
    [
        "     **/\\**   ",
        "    */  \\*    ",
        "   */ ◉  \\*   ",
        "  */______\\*  ",
        "      ||      ",
        "   III III    ",
    ],
    # Kare 7 — ters (gözü kapalı)
    [
        "      /\\      ",
        "     /==\\     ",
        "    /      \\  ",
        "   /________\\ ",
        "      ||      ",
        "   III III    ",
    ],
]

# Beyin ASCII animasyon kareleri
BRAIN_FRAMES = [
    # Kare 0
    [
        "    _______    ",
        "   /       \\   ",
        "  | (o) (o) |  ",
        "  |   ~~~   |  ",
        "   \\_______/   ",
        "    |||||||||  ",
        "    |||||||||  ",
    ],
    # Kare 1
    [
        "    _______    ",
        "   / ~~~~~ \\   ",
        "  | (◉) (◉) |  ",
        "  |   ~~~   |  ",
        "   \\_______/   ",
        "    |||||||||  ",
        "    |||||||||  ",
    ],
    # Kare 2
    [
        "    _______    ",
        "   /       \\   ",
        "  | (@) (@) |  ",
        "  |   ---   |  ",
        "   \\_______/   ",
        "    ╔═══════╗  ",
        "    ╚═══════╝  ",
    ],
    # Kare 3 — bağlantı kuruluyor
    [
        "   ________    ",
        "  /════════\\   ",
        " | ●●●●●●●● |  ",
        " |  UPLOAD  |  ",
        "  \\________/   ",
        "   ~~~~~~~~~~~  ",
        "   AKTARIM...  ",
    ],
]

# ─── Görsel Element Sınıfı ────────────────────────────────────────────────────

class VisualElements:
    """
    Terminal psikolojik görsel elementleri yönetici sınıfı.

    Her element bağımsız çağrılabilir.
    Animasyonlar frame sayacı ile senkronize edilir.
    """

    def __init__(self):
        # Düşen sayıların sütun durumu
        self._falling_cols: dict = {}
        # Sistem günlüğü scrollback tamponu
        self._log_buffer: List[str] = []
        # İllüzyon noktası durumu
        self._illusion_phase: float = 0.0
        # Matrix damlacık renk durumu
        self._matrix_colors: dict = {}

    # ──────────────────────────────────────────────────────────────────────────
    # DÖNEN ÜÇGEN GÖZ
    # ──────────────────────────────────────────────────────────────────────────

    def rotating_triangle_eye(
        self,
        stdscr,
        frame: int,
        y: int,
        x: int,
        color_pair: int = 3,
        intense: bool = False,
    ) -> None:
        """
        Dönen üçgen göz sembolü çizer (Illuminati tarzı).

        Frame sayacına göre 8 animasyon karesi arasında geçiş yapar.

        Args:
            stdscr:     Curses penceresi
            frame:      Geçerli frame sayısı
            y, x:       Sol üst köşe koordinatları
            color_pair: Renk çifti (varsayılan: cyan)
            intense:    True ise daha agresif renk/efekt
        """
        h, w = stdscr.getmaxyx()

        # Hangi animasyon karesi?
        anim_speed = 6 if intense else 10
        kare_idx = (frame // anim_speed) % len(EYE_FRAMES)
        kare = EYE_FRAMES[kare_idx]

        # Renk ayarla
        if intense:
            attr = curses.color_pair(2) | curses.A_BOLD
        else:
            # Titreyen renk efekti
            blink = (frame // 20) % 2
            attr_base = curses.color_pair(color_pair)
            attr = attr_base | (curses.A_BOLD if blink else curses.A_DIM)

        for i, line in enumerate(kare):
            cy = y + i
            if cy >= h - 1:
                break
            cx = max(0, x)
            try:
                visible_line = line[:w - cx - 1]
                if visible_line:
                    stdscr.addstr(cy, cx, visible_line, attr)
            except (curses.error, ValueError):
                pass

    # ──────────────────────────────────────────────────────────────────────────
    # SAHTE SİSTEM GÜNLÜKLERİ
    # ──────────────────────────────────────────────────────────────────────────

    def fake_system_logs(
        self,
        stdscr,
        y: int,
        x: int,
        count: int,
        frame: int,
        intensity: float = 0.3,
    ) -> None:
        """
        Kaydırılan sahte sistem günlük satırları çizer.

        Günlükler otomatik olarak ilerler ve renk kod sistemine sahiptir:
          OK   → yeşil
          WARN → sarı
          CRIT → kırmızı  + bold
          ERR  → kırmızı

        Args:
            stdscr:    Curses penceresi
            y, x:      Başlangıç koordinatları
            count:     Gösterilecek satır sayısı
            frame:     Animasyon frame sayısı
            intensity: Bozulma yoğunluğu
        """
        h, w = stdscr.getmaxyx()

        # Tampon güncelle — her 15 frame'de yeni log ekle
        if frame % 15 == 0 or len(self._log_buffer) < count:
            new_log = random.choice(FAKE_LOG_POOL)
            # Zaman damgası ekle
            ts = f"[{random.randint(0,23):02d}:{random.randint(0,59):02d}:{random.randint(0,59):02d}]"
            self._log_buffer.append(f"{ts} {new_log}")
            # Tampon sınırı
            if len(self._log_buffer) > 100:
                self._log_buffer = self._log_buffer[-50:]

        # Son `count` satırı göster
        display_logs = self._log_buffer[-count:]

        for i, log_line in enumerate(display_logs):
            cy = y + i
            if cy >= h - 1:
                break

            # Renk belirle
            if "CRIT" in log_line:
                attr = curses.color_pair(2) | curses.A_BOLD
                if (frame // 10) % 2 == 0 and intensity > 0.5:
                    attr |= curses.A_REVERSE
            elif "WARN" in log_line:
                attr = curses.color_pair(4) | curses.A_BOLD
            elif "ERR" in log_line:
                attr = curses.color_pair(2)
            elif "OK" in log_line:
                attr = curses.color_pair(1)
            else:
                attr = curses.color_pair(3) | curses.A_DIM

            # Yüksek yoğunlukta satırları boz
            if intensity > 0.5 and random.random() < intensity * 0.2:
                corrupt_count = int(len(log_line) * intensity * 0.1)
                log_chars = list(log_line)
                for _ in range(corrupt_count):
                    ci = random.randint(0, len(log_chars) - 1)
                    if log_chars[ci] not in ('[', ']', ' '):
                        log_chars[ci] = random.choice("░▒▓!#@$%")
                log_line = "".join(log_chars)

            try:
                visible = log_line[:w - x - 1]
                if visible:
                    stdscr.addstr(cy, x, visible, attr)
            except (curses.error, ValueError):
                pass

    # ──────────────────────────────────────────────────────────────────────────
    # DÜŞEN SAYILAR (MATRİX TARZI)
    # ──────────────────────────────────────────────────────────────────────────

    def falling_numbers(
        self,
        stdscr,
        frame: int,
        color_pair: int = 1,
        density: float = 0.3,
    ) -> None:
        """
        Matrix tarzı düşen karakter yağmuru.

        Her sütun bağımsız bir "damla" animasyonuna sahiptir.
        Sütunlar farklı hızlarda aşağı iner.

        Args:
            stdscr:     Curses penceresi
            frame:      Animasyon frame sayısı
            color_pair: Temel renk çifti
            density:    0.0–1.0 sütun yoğunluğu
        """
        h, w = stdscr.getmaxyx()

        # Aktif sütun sayısını yoğunluğa göre hesapla
        max_cols = max(1, int((w // 2) * density))

        # Yeni sütunlar ekle
        while len(self._falling_cols) < max_cols:
            col = random.randint(0, w - 2)
            if col not in self._falling_cols:
                self._falling_cols[col] = {
                    "y": random.randint(0, h - 1),
                    "speed": random.randint(1, 3),
                    "length": random.randint(3, min(15, h // 2)),
                    "chars": [random.choice("01アイウエオ234567") for _ in range(20)],
                    "bright": random.random() > 0.7,
                }

        # Öldü sütunları temizle
        dead = [c for c, d in self._falling_cols.items() if d["y"] > h + d["length"]]
        for c in dead:
            del self._falling_cols[c]

        # Sütunları çiz
        for col, data in list(self._falling_cols.items()):
            # Hıza göre ilerle
            if frame % max(1, 4 - data["speed"]) == 0:
                data["y"] += 1

            # Damlayı çiz
            for i in range(data["length"]):
                draw_y = data["y"] - i
                if draw_y < 0 or draw_y >= h:
                    continue

                if i == 0:
                    # En önde beyaz/parlak
                    char = random.choice("01")
                    attr = curses.color_pair(5) | curses.A_BOLD
                elif i < 3:
                    # Aktif parlak
                    char = random.choice(data["chars"])
                    attr = curses.color_pair(color_pair) | curses.A_BOLD
                elif i < data["length"] - 2:
                    # Normal
                    char = random.choice(data["chars"])
                    attr = curses.color_pair(color_pair)
                else:
                    # Soluk iz
                    char = random.choice("01")
                    attr = curses.color_pair(color_pair) | curses.A_DIM

                try:
                    stdscr.addch(draw_y, col, char, attr)
                except (curses.error, ValueError, OverflowError):
                    pass

    # ──────────────────────────────────────────────────────────────────────────
    # BEYİN ASCII ANİMASYON
    # ──────────────────────────────────────────────────────────────────────────

    def brain_ascii(
        self,
        stdscr,
        y: int,
        x: int,
        frame: int,
        color_pair: int = 6,
    ) -> None:
        """
        Beyin ASCII animasyonu çizer.

        4 animasyon karesi arasında geçiş yapar.
        Yüksek framede "upload" karesine geçer.

        Args:
            stdscr:     Curses penceresi
            y, x:       Sol üst köşe koordinatları
            frame:      Animasyon frame sayısı
            color_pair: Renk çifti
        """
        h, w = stdscr.getmaxyx()

        kare_idx = (frame // 12) % len(BRAIN_FRAMES)
        kare = BRAIN_FRAMES[kare_idx]

        # Bağlantı karesi daha parlak
        if kare_idx == 3:
            attr = curses.color_pair(2) | curses.A_BOLD
        else:
            attr = curses.color_pair(color_pair) | curses.A_DIM

        for i, line in enumerate(kare):
            cy = y + i
            if cy >= h - 1:
                break
            cx = max(0, x)
            try:
                visible = line[:w - cx - 1]
                if visible:
                    stdscr.addstr(cy, cx, visible, attr)
            except (curses.error, ValueError):
                pass

    # ──────────────────────────────────────────────────────────────────────────
    # İLLÜZYON NOKTA EFEKTİ
    # ──────────────────────────────────────────────────────────────────────────

    def illusion_dots(
        self,
        stdscr,
        center_y: int,
        center_x: int,
        frame: int,
        radius: int = 8,
    ) -> None:
        """
        Merkeze odaklanan titreyen daire noktaları (optik illüzyon).

        Noktalar sinüs dalgasıyla pulsar gibi titreşir.
        Uzun süre bakıldığında gözü yorar — psikolojik etki.

        Args:
            stdscr:   Curses penceresi
            center_y: Daire merkezi Y
            center_x: Daire merkezi X
            frame:    Animasyon frame sayısı
            radius:   Daire yarıçapı (karakterde)
        """
        h, w = stdscr.getmaxyx()

        # Merkez nokta - büyük, yanıp sönen
        phase = (frame * 0.1) % (2 * math.pi)
        center_bright = int(abs(math.sin(phase)) * 3)

        center_chars = ["·", "•", "●", "◎"]
        center_ch = center_chars[min(center_bright, len(center_chars) - 1)]

        if 0 <= center_y < h and 0 <= center_x < w - 1:
            try:
                attr = curses.color_pair(5) | curses.A_BOLD
                stdscr.addch(center_y, center_x, center_ch, attr)
            except (curses.error, ValueError, OverflowError):
                pass

        # Çevresindeki noktalar
        num_dots = 16
        for i in range(num_dots):
            angle = (2 * math.pi * i / num_dots) + (frame * 0.03)

            # Titreşen yarıçap
            r_phase = (frame * 0.05 + i * 0.3) % (2 * math.pi)
            r = radius + int(math.sin(r_phase) * 2)

            dy = int(math.sin(angle) * r * 0.5)  # Terminal karakter oranı
            dx = int(math.cos(angle) * r)

            dot_y = center_y + dy
            dot_x = center_x + dx

            if 0 <= dot_y < h - 1 and 0 <= dot_x < w - 2:
                # Parlaklık sinüs dalgasıyla değişir
                bright_phase = (frame * 0.08 + i * 0.5) % (2 * math.pi)
                is_bright = math.sin(bright_phase) > 0

                dot_chars = ["·", "•", "◦", "○"]
                dot_ch = "●" if is_bright else random.choice(dot_chars)

                if is_bright:
                    attr = curses.color_pair(3) | curses.A_BOLD
                else:
                    attr = curses.color_pair(3) | curses.A_DIM

                try:
                    stdscr.addch(dot_y, dot_x, dot_ch, attr)
                except (curses.error, ValueError, OverflowError):
                    pass

    # ──────────────────────────────────────────────────────────────────────────
    # SAHTE TARAMA MESAJI
    # ──────────────────────────────────────────────────────────────────────────

    def fake_scan(
        self,
        stdscr,
        y: int,
        x: int,
        message: str,
        progress: float,
        frame: int,
        color_pair: int = 4,
    ) -> None:
        """
        Sahte tarama çubuğu ve ilerleme göstergesi.

        Args:
            stdscr:     Curses penceresi
            y, x:       Pozisyon
            message:    Tarama mesajı
            progress:   0.0–1.0 ilerleme oranı
            frame:      Animasyon frame sayısı
            color_pair: Renk çifti
        """
        h, w = stdscr.getmaxyx()
        if y >= h - 1:
            return

        # İlerleme çubuğu boyutu
        bar_width = min(30, w - x - len(message) - 10)
        if bar_width < 5:
            return

        filled = int(bar_width * progress)
        empty = bar_width - filled

        # Animasyonlu doldurma karakteri
        fill_chars = "█▓▒░"
        fill_char = fill_chars[(frame // 5) % len(fill_chars)]

        bar = f"[{'█' * filled}{fill_char if filled < bar_width else ''}{'░' * max(0, empty - 1)}]"
        pct = int(progress * 100)

        # Yanıp sönen mesaj
        blink = (frame // 15) % 2
        msg_attr = curses.color_pair(color_pair) | curses.A_BOLD
        bar_attr = curses.color_pair(1)
        pct_attr = curses.color_pair(3) | (curses.A_BOLD if blink else curses.A_DIM)

        try:
            line = f"{message[:w - x - bar_width - 10]} {bar} {pct:3d}%"
            stdscr.addstr(y, x, line[:w - x - 1], msg_attr)
        except (curses.error, ValueError):
            pass

    # ──────────────────────────────────────────────────────────────────────────
    # UYARI BLOĞU
    # ──────────────────────────────────────────────────────────────────────────

    def warning_flash_block(
        self,
        stdscr,
        y: int,
        x: int,
        text: str,
        frame: int,
    ) -> None:
        """
        Yanıp sönen kırmızı uyarı bloğu.

        Kritik anlarda ekrana büyük bir uyarı çizer.

        Args:
            stdscr: Curses penceresi
            y, x:   Pozisyon
            text:   Uyarı metni
            frame:  Animasyon frame sayısı
        """
        h, w = stdscr.getmaxyx()
        blink = (frame // 8) % 2

        if y >= h - 1:
            return

        width = min(len(text) + 4, w - x - 1)
        border = "█" * width

        lines = [
            border,
            f"██ {text[:width - 4]} ██",
            border,
        ]

        for i, line in enumerate(lines):
            cy = y + i
            if cy >= h - 1:
                break
            attr = curses.color_pair(7) | curses.A_BOLD
            if blink:
                attr |= curses.A_REVERSE
            try:
                stdscr.addstr(cy, x, line[:w - x - 1], attr)
            except (curses.error, ValueError):
                pass

    # ──────────────────────────────────────────────────────────────────────────
    # VERİ AKIŞ GÖRSELİ
    # ──────────────────────────────────────────────────────────────────────────

    def data_stream(
        self,
        stdscr,
        y: int,
        x: int,
        width: int,
        frame: int,
        direction: str = "right",
        color_pair: int = 1,
    ) -> None:
        """
        Yatay veri akış animasyonu.

        Verinin bir noktadan diğerine aktarıldığını görsel olarak gösterir.

        Args:
            stdscr:     Curses penceresi
            y, x:       Başlangıç koordinatları
            width:      Akış genişliği
            frame:      Animasyon frame sayısı
            direction:  "right" veya "left"
            color_pair: Renk çifti
        """
        h, w = stdscr.getmaxyx()
        if y >= h - 1:
            return

        # Akış karakteri pozisyonu
        speed = 3
        pos = (frame * speed) % width

        line = []
        for i in range(width):
            dist = abs(i - pos)
            if dist == 0:
                char = "▶" if direction == "right" else "◀"
                attr = curses.color_pair(5) | curses.A_BOLD
            elif dist < 3:
                char = "─"
                attr = curses.color_pair(color_pair) | curses.A_BOLD
            elif dist < 7:
                char = "·"
                attr = curses.color_pair(color_pair) | curses.A_DIM
            else:
                char = " "
                attr = curses.color_pair(color_pair) | curses.A_DIM

            if i < width:
                try:
                    stdscr.addch(y, x + i, char, attr)
                except (curses.error, ValueError, OverflowError):
                    pass

    # ──────────────────────────────────────────────────────────────────────────
    # HEX DUMP GÖRSELİ
    # ──────────────────────────────────────────────────────────────────────────

    def hex_dump_visual(
        self,
        stdscr,
        y: int,
        x: int,
        rows: int,
        frame: int,
    ) -> None:
        """
        Sahte hex dump ekranı — gerçekçi bellek görüntüsü.

        Args:
            stdscr: Curses penceresi
            y, x:   Başlangıç koordinatları
            rows:   Satır sayısı
            frame:  Animasyon frame sayısı
        """
        h, w = stdscr.getmaxyx()

        # Temel adres (frame'e göre kayıyor gibi görünür)
        base_addr = 0x7FFE0000 + frame * 0x10

        for i in range(rows):
            cy = y + i
            if cy >= h - 1:
                break

            addr = base_addr + i * 16
            # 16 byte hex değer
            hex_bytes = " ".join(
                f"{random.randint(0, 255):02X}" for _ in range(8)
            )
            # ASCII gösterim
            ascii_rep = "".join(
                chr(random.randint(33, 126)) if random.random() > 0.3 else "."
                for _ in range(8)
            )

            line = f" {addr:08X}  {hex_bytes}  |{ascii_rep}|"

            # Zaman zaman satır bozulur
            if random.random() < 0.1:
                attr = curses.color_pair(2) | curses.A_DIM
            else:
                attr = curses.color_pair(1) | curses.A_DIM

            try:
                stdscr.addstr(cy, x, line[:w - x - 1], attr)
            except (curses.error, ValueError):
                pass

    # ──────────────────────────────────────────────────────────────────────────
    # PULSE ÇEMBER
    # ──────────────────────────────────────────────────────────────────────────

    def pulse_ring(
        self,
        stdscr,
        center_y: int,
        center_x: int,
        frame: int,
        max_radius: int = 10,
    ) -> None:
        """
        Dışa doğru yayılan halka animasyonu.
        Bir "ping" veya alarm efekti için kullanılır.

        Args:
            stdscr:     Curses penceresi
            center_y/x: Merkez koordinatlar
            frame:      Animasyon frame sayısı
            max_radius: Maksimum halka yarıçapı
        """
        h, w = stdscr.getmaxyx()

        radius = (frame * 2) % (max_radius * 2)
        if radius > max_radius:
            radius = max_radius * 2 - radius  # Geri gel

        ring_chars = "○◎●◉"
        ring_char = ring_chars[radius % len(ring_chars)]

        num_points = max(8, int(2 * math.pi * radius * 1.5))

        for i in range(num_points):
            angle = 2 * math.pi * i / num_points
            dy = int(math.sin(angle) * radius * 0.5)
            dx = int(math.cos(angle) * radius)

            py = center_y + dy
            px = center_x + dx

            if 0 <= py < h - 1 and 0 <= px < w - 2:
                # Soluk -> parlak -> soluk
                brightness = 1.0 - (radius / max_radius)
                attr = curses.color_pair(3)
                if brightness > 0.6:
                    attr |= curses.A_BOLD
                else:
                    attr |= curses.A_DIM

                try:
                    stdscr.addch(py, px, ring_char, attr)
                except (curses.error, ValueError, OverflowError):
                    pass

    # ──────────────────────────────────────────────────────────────────────────
    # NÖRAL AĞ GÖRSELİ
    # ──────────────────────────────────────────────────────────────────────────

    def neural_network_visual(
        self,
        stdscr,
        y: int,
        x: int,
        frame: int,
    ) -> None:
        """
        Yapay nöral ağ animasyonu — düğümler ve bağlantılar.

        Args:
            stdscr: Curses penceresi
            y, x:   Sol üst köşe
            frame:  Animasyon frame sayısı
        """
        h, w = stdscr.getmaxyx()

        # Statik düğüm pozisyonları (3 katman)
        layers = [
            [(0, 0), (4, 0), (8, 0)],           # Giriş katmanı
            [(2, 10), (6, 10), (10, 10), (4, 10)],  # Gizli katman
            [(4, 20), (8, 20)],                  # Çıkış katmanı
        ]

        # Aktif nöron (frame ile değişir)
        active_neuron = frame % 9

        neuron_idx = 0
        for layer_idx, layer in enumerate(layers):
            for node_idx, (dy, dx) in enumerate(layer):
                ny = y + dy
                nx = x + dx

                if ny >= h - 1 or nx >= w - 2:
                    neuron_idx += 1
                    continue

                is_active = (neuron_idx == active_neuron)
                char = "◉" if is_active else "○"
                attr = (
                    curses.color_pair(3) | curses.A_BOLD
                    if is_active
                    else curses.color_pair(1) | curses.A_DIM
                )

                try:
                    stdscr.addch(ny, nx, char, attr)
                except (curses.error, ValueError, OverflowError):
                    pass

                # Bağlantı çizgileri (basit yatay çizgi)
                if layer_idx < len(layers) - 1:
                    for _ in range(8):
                        cx_pos = nx + _ + 1
                        if cx_pos >= w - 1:
                            break
                        connect_char = "·" if _ % 2 == 0 else " "
                        try:
                            stdscr.addch(ny, cx_pos, connect_char,
                                         curses.color_pair(1) | curses.A_DIM)
                        except (curses.error, ValueError, OverflowError):
                            pass

                neuron_idx += 1


# ─── Modül Test Bloğu ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    def _test(stdscr):
        curses.start_color()
        curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
        curses.init_pair(2, curses.COLOR_RED, curses.COLOR_BLACK)
        curses.init_pair(3, curses.COLOR_CYAN, curses.COLOR_BLACK)
        curses.init_pair(4, curses.COLOR_YELLOW, curses.COLOR_BLACK)
        curses.init_pair(5, curses.COLOR_WHITE, curses.COLOR_BLACK)
        curses.init_pair(6, curses.COLOR_MAGENTA, curses.COLOR_BLACK)
        curses.init_pair(7, curses.COLOR_WHITE, curses.COLOR_RED)
        curses.curs_set(0)

        ve = VisualElements()

        for frame in range(300):
            stdscr.clear()
            max_y, max_x = stdscr.getmaxyx()

            # Göz
            ve.rotating_triangle_eye(stdscr, frame, 2, max_x // 2 - 7)
            # Beyin
            ve.brain_ascii(stdscr, max_y // 2, 2, frame)
            # Düşen sayılar
            ve.falling_numbers(stdscr, frame)
            # Log
            ve.fake_system_logs(stdscr, max_y - 6, 2, 5, frame)
            # Tarama
            ve.fake_scan(stdscr, max_y - 2, 2, "Tarama:", frame / 300, frame)
            # İllüzyon
            ve.illusion_dots(stdscr, max_y // 2, max_x // 2, frame)

            stdscr.refresh()
            time.sleep(0.05)

    curses.wrapper(_test)
