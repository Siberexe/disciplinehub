#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║       TERMİNAL PSİKOLOJİK SİMÜLASYON MOTORU — GLITCH MOTORU               ║
║       glitch_engine.py  |  Versiyon: 4.2.1  |  @LonySoraz                 ║
╚══════════════════════════════════════════════════════════════════════════════╝

Bu modül tüm görsel glitch efektlerini üretir:
  • CRT gürültüsü (1990'lar televizyon arızası)
  • Statik kar flaşı
  • Metin bozma (karakter korupsiyonu)
  • Ekran kırılması
  • Tarama çizgisi efekti
  • Yatay yırtılma
  • Rastgele titreme
  • Frame düşürme simülasyonu
  • Yoğunluk kademeli artış desteği

Tüm fonksiyonlar curses penceresi üzerinde çalışır.
Hata toleranslıdır: curses.error durumunda sessizce geçer.
"""

import curses
import random
import time
import math
import string
from typing import Optional, Tuple, List

# ─── Karakter Kümeleri ────────────────────────────────────────────────────────

# Blok/kutu çizim karakterleri — CRT pikseli görünümü
BLOCK_CHARS   = "░▒▓█▄▀▌▐■□▪▫"
# Gürültü / parazit karakterleri
NOISE_CHARS   = "@#$%^&*!~`|/<>{}[]?;:+-="
# TV statik kar karakterleri
STATIC_CHARS  = "░▒▓█ ▄▀▌▐"
# Bozma karakterleri (metin korupsiyonu)
CORRUPT_CHARS = string.ascii_letters + string.digits + "!@#$%^&*()-_=+[]{}|;':,.<>?/"
# Yoğun glitch karakterleri
HEAVY_GLITCH  = "▓▒░█▄▀■□◘◙◚◛◜◝◞◟◠◡◢◣◤◥"
# Matrix tarzı karakterler
MATRIX_CHARS  = "01アイウエオカキクケコサシスセソタチツテトナニヌネノ"


# ─── GlitchEngine Sınıfı ─────────────────────────────────────────────────────

class GlitchEngine:
    """
    Terminal ekranında CRT televizyon arızası simülasyonu yapan motor.

    Yoğunluk (intensity) 0.0 ile 1.0 arasında kademeli artar.
    Her sahne geçişinde yoğunluk bir miktar yükseltilir.

    Kullanım:
        ge = GlitchEngine()
        ge.set_intensity(0.5)
        ge.apply_all(stdscr)      # Tüm efektleri uygula
    """

    # Varsayılan CRT tarama hızı (satır/saniye)
    SCAN_SPEED = 30

    def __init__(self):
        # Anlık glitch yoğunluğu (0.0 = yok, 1.0 = maksimum)
        self.intensity: float = 0.0

        # Frame sayacı — animasyon senkronizasyonu için
        self.frame: int = 0

        # Yırtık satır listesi (yatay tear için)
        self._tear_rows: List[int] = []

        # CRT parlaklık dalgalanması için faz
        self._flicker_phase: float = 0.0

        # Son statik flaş zamanı
        self._last_static: float = 0.0

        # Ekran boyutu önbelleği
        self._cached_size: Tuple[int, int] = (24, 80)

        # Bozuk satır hafızası (süreklilik için)
        self._corrupt_memory: dict = {}

    # ──────────────────────────────────────────────────────────────────────────
    # TEMEL KONTROL
    # ──────────────────────────────────────────────────────────────────────────

    def set_intensity(self, intensity: float) -> None:
        """
        Glitch yoğunluğunu ayarlar.

        Args:
            intensity: 0.0 (yok) ile 1.0 (maksimum) arası değer
        """
        self.intensity = max(0.0, min(1.0, float(intensity)))

    def increase_intensity(self, delta: float = 0.03) -> None:
        """Yoğunluğu kademeli artırır"""
        self.set_intensity(self.intensity + delta)

    def tick(self) -> None:
        """
        Frame sayacını ilerletir.
        Her çizim döngüsünün sonunda çağrılmalıdır.
        """
        self.frame += 1
        self._flicker_phase = (self._flicker_phase + 0.15) % (2 * math.pi)

    def reset(self) -> None:
        """Motoru sıfırlar (yeni sahne başlangıcı için)"""
        self.intensity = 0.0
        self.frame = 0
        self._tear_rows.clear()
        self._corrupt_memory.clear()

    def _safe_size(self, stdscr) -> Tuple[int, int]:
        """Ekran boyutunu güvenli şekilde alır"""
        try:
            h, w = stdscr.getmaxyx()
            self._cached_size = (h, w)
            return h, w
        except Exception:
            return self._cached_size

    # ──────────────────────────────────────────────────────────────────────────
    # GLITCH FONKSİYONLARI
    # ──────────────────────────────────────────────────────────────────────────

    def glitch_text(self, text: str, intensity: Optional[float] = None) -> str:
        """
        Metni glitch efektiyle bozar.

        Yüksek yoğunlukta karakter oranı artar:
          • intensity < 0.3 → hafif bozulma
          • intensity 0.3–0.6 → orta bozulma
          • intensity > 0.6 → ağır bozulma

        Args:
            text:      Kaynak metin
            intensity: Geçersiz kılma değeri (None = self.intensity)

        Returns:
            str: Bozulmuş metin
        """
        lvl = intensity if intensity is not None else self.intensity

        if lvl <= 0.0:
            return text

        # Bozulma olasılıkları
        corrupt_prob = lvl * 0.35
        glitch_prob  = lvl * 0.20
        heavy_prob   = lvl * 0.10

        result = []
        for ch in text:
            r = random.random()
            if ch != ' ':
                if r < heavy_prob:
                    result.append(random.choice(HEAVY_GLITCH))
                elif r < corrupt_prob:
                    result.append(random.choice(CORRUPT_CHARS))
                elif r < corrupt_prob + glitch_prob:
                    result.append(random.choice(NOISE_CHARS))
                else:
                    result.append(ch)
            else:
                # Boşlukları da bazen boz
                if random.random() < lvl * 0.05:
                    result.append(random.choice(" _░"))
                else:
                    result.append(ch)

        return "".join(result)

    def character_corruption(self, text: str, rate: float) -> str:
        """
        Sabit oranda karakter bozma.

        Args:
            text: Kaynak metin
            rate: 0.0–1.0 bozulma oranı

        Returns:
            str: Bozulmuş metin
        """
        result = []
        for ch in text:
            if ch not in (' ', '\n', '\t') and random.random() < rate:
                result.append(random.choice(CORRUPT_CHARS))
            else:
                result.append(ch)
        return "".join(result)

    def crt_noise(self, stdscr, intensity: Optional[float] = None) -> None:
        """
        CRT ekran gürültüsü — Rastgele konumlara parazit karakterleri çizer.

        Yoğunluk arttıkça daha fazla piksel bozulur.
        Düşük yoğunlukta (< 0.05) hiçbir şey çizilmez (performans).

        Args:
            stdscr:    Curses penceresi
            intensity: Geçersiz kılma değeri
        """
        lvl = intensity if intensity is not None else self.intensity
        if lvl < 0.05:
            return

        h, w = self._safe_size(stdscr)

        # Çizilecek piksel sayısı
        pixel_count = int(h * w * lvl * 0.12)

        # Renk seçenekleri
        colors = [
            curses.color_pair(1),
            curses.color_pair(2),
            curses.color_pair(3),
            curses.color_pair(5) | curses.A_DIM,
        ]

        for _ in range(pixel_count):
            y = random.randint(0, h - 1)
            x = random.randint(0, w - 2)
            char = random.choice(STATIC_CHARS)
            attr = random.choice(colors)

            # Parlak piksel efekti
            if random.random() < lvl * 0.3:
                attr |= curses.A_BOLD

            try:
                stdscr.addch(y, x, char, attr)
            except (curses.error, ValueError, OverflowError):
                pass

    def scanline_effect(self, stdscr, intensity: Optional[float] = None) -> None:
        """
        CRT tarama çizgisi efekti.

        Animasyonlu bir parlak çizgi ekranda aşağı doğru ilerler.
        Çift satırlar hafifçe karartılır (CRT tarama simulasyonu).

        Args:
            stdscr:    Curses penceresi
            intensity: Geçersiz kılma değeri
        """
        lvl = intensity if intensity is not None else self.intensity
        if lvl < 0.08:
            return

        h, w = self._safe_size(stdscr)

        # Aktif tarama çizgisi pozisyonu
        scan_y = int((self.frame * self.SCAN_SPEED / 60) % h)

        # Çift satırları karart
        dim_prob = lvl * 0.4
        for y in range(0, h, 2):
            if random.random() < dim_prob:
                try:
                    stdscr.chgat(y, 0, w, curses.A_DIM)
                except curses.error:
                    pass

        # Aktif tarama çizgisi — parlak çizgi
        try:
            stdscr.chgat(scan_y % h, 0, w, curses.A_REVERSE | curses.A_DIM)
        except curses.error:
            pass

        # Çizginin hemen üstünde solma efekti
        if scan_y > 0:
            try:
                stdscr.chgat((scan_y - 1) % h, 0, w, curses.A_DIM)
            except curses.error:
                pass

    def horizontal_tear(self, stdscr, intensity: Optional[float] = None) -> None:
        """
        Yatay yırtılma efekti — satırları yanlara kaydırır.

        Eski CRT görüntü senkronizasyon hatalarını simüle eder.
        Yüksek yoğunlukta birden fazla satır aynı anda kayar.

        Args:
            stdscr:    Curses penceresi
            intensity: Geçersiz kılma değeri
        """
        lvl = intensity if intensity is not None else self.intensity
        if lvl < 0.15:
            return

        h, w = self._safe_size(stdscr)

        # Kaç satır yırtılacak
        num_tears = max(1, int(lvl * 6))

        for _ in range(num_tears):
            y = random.randint(1, h - 2)
            # Kaydırma miktarı — büyük yoğunlukta daha fazla kayar
            max_shift = int(lvl * 12)
            shift = random.randint(-max_shift, max_shift)
            if shift == 0:
                continue

            try:
                # Mevcut satır içeriğini oku
                row = ""
                for x in range(w - 1):
                    try:
                        ch_val = stdscr.inch(y, x)
                        ch = ch_val & 0xFF
                        row += chr(ch) if 32 <= ch < 127 else " "
                    except Exception:
                        row += " "

                # Satırı temizle
                stdscr.move(y, 0)
                stdscr.clrtoeol()

                # Kaydırılmış konuma yaz
                if shift > 0:
                    # Sağa kaydır
                    content = row[:w - shift - 1]
                    if content:
                        color = random.choice([
                            curses.color_pair(2) | curses.A_BOLD,
                            curses.color_pair(6),
                            curses.color_pair(1) | curses.A_DIM,
                        ])
                        stdscr.addstr(y, shift, content, color)
                else:
                    # Sola kaydır
                    abs_shift = abs(shift)
                    content = row[abs_shift:w - 1]
                    if content:
                        color = random.choice([
                            curses.color_pair(2) | curses.A_BOLD,
                            curses.color_pair(6),
                        ])
                        stdscr.addstr(y, 0, content, color)

            except (curses.error, ValueError):
                pass

    def screen_break(self, stdscr, intensity: Optional[float] = None) -> None:
        """
        Ekran kırılması — rastgele bloklarda parazit çizer.

        Büyük dikdörtgen alanlar noise karakterlerle doldurulur.
        CRT veya dijital ekran arızasını simüle eder.

        Args:
            stdscr:    Curses penceresi
            intensity: Geçersiz kılma değeri
        """
        lvl = intensity if intensity is not None else self.intensity
        if lvl < 0.1:
            return

        h, w = self._safe_size(stdscr)

        # Blok sayısı
        num_blocks = max(1, int(lvl * 8))

        color_options = [
            curses.color_pair(1),
            curses.color_pair(2) | curses.A_BOLD,
            curses.color_pair(4),
            curses.color_pair(6),
            curses.color_pair(3) | curses.A_DIM,
        ]

        for _ in range(num_blocks):
            # Blok boyutu
            bh = random.randint(1, max(2, int(lvl * 5)))
            bw = random.randint(3, max(5, int(lvl * 20)))

            # Blok pozisyonu
            by = random.randint(0, max(0, h - bh - 1))
            bx = random.randint(0, max(0, w - bw - 1))

            color = random.choice(color_options)

            for dy in range(bh):
                row_chars = "".join(
                    random.choice(HEAVY_GLITCH + NOISE_CHARS)
                    for _ in range(bw)
                )
                try:
                    stdscr.addstr(by + dy, bx, row_chars[:w - bx - 1], color)
                except (curses.error, ValueError):
                    pass

    def static_flash(
        self,
        stdscr,
        duration: float = 0.8,
        color_pair: int = 1,
        with_horizontal_distortion: bool = True,
    ) -> None:
        """
        TV statik kar efekti — ekranı kısa süre statik karla kaplar.

        Her frame farklı bir gürültü deseni üretir.
        İsteğe bağlı yatay bozulma eklenebilir.

        Args:
            stdscr:                   Curses penceresi
            duration:                 Flaş süresi (saniye)
            color_pair:               Kullanılacak renk çifti
            with_horizontal_distortion: True ise yatay yırtılma eklenir
        """
        h, w = self._safe_size(stdscr)
        end_time = time.time() + duration

        # Kırmızı mod rengi için ek BOLD
        extra_attr = curses.A_BOLD if color_pair == 2 else 0

        while time.time() < end_time:
            # Her satırı statik karakterlerle doldur
            for y in range(h):
                # Satır yoğunluğu — bazı satırlar daha parlak
                row_bright = random.random() > 0.6

                line = ""
                for _ in range(w - 1):
                    # Boşluk ağırlıklı — gerçek TV karı gibi
                    pool = STATIC_CHARS + "   "
                    line += random.choice(pool)

                attr = curses.color_pair(color_pair) | extra_attr
                if row_bright:
                    attr |= curses.A_BOLD

                try:
                    stdscr.addstr(y, 0, line, attr)
                except curses.error:
                    pass

            # Yatay bozulma
            if with_horizontal_distortion and random.random() > 0.4:
                self.horizontal_tear(stdscr, random.uniform(0.3, 0.8))

            # Dikey senkronizasyon kayması simülasyonu
            if random.random() > 0.7:
                shift_lines = random.randint(1, 4)
                for sy in range(shift_lines):
                    try:
                        stdscr.move(sy, 0)
                        stdscr.clrtoeol()
                    except curses.error:
                        pass

            stdscr.refresh()

            # Frame hızı — gerçekçi titreme için değişken bekleme
            sleep_t = random.uniform(0.015, 0.045)
            time.sleep(sleep_t)

    def random_flicker(self, stdscr, intensity: Optional[float] = None) -> None:
        """
        Rastgele ekran titremesi.

        CRT'nin voltaj dalgalanmasını simüle eder.
        Düşük yoğunlukta nadiren olur, yüksekte sürekli titreyebilir.

        Args:
            stdscr:    Curses penceresi
            intensity: Geçersiz kılma değeri
        """
        lvl = intensity if intensity is not None else self.intensity

        # Titreme olasılığı yoğunlukla artar
        flicker_prob = lvl * 0.4
        if random.random() > flicker_prob:
            return

        try:
            # Ekranı kısa süre tersine çevir
            h, w = self._safe_size(stdscr)
            stdscr.chgat(0, 0, -1, curses.A_REVERSE | curses.A_DIM)
            stdscr.refresh()
            time.sleep(random.uniform(0.01, 0.04))

            stdscr.chgat(0, 0, -1, curses.A_NORMAL)
            stdscr.refresh()
            time.sleep(random.uniform(0.005, 0.02))
        except Exception:
            pass

    def frame_drop(self, stdscr, intensity: Optional[float] = None) -> None:
        """
        Frame düşürme simülasyonu — ekranı kısa süre dondurur.

        Yüksek yoğunlukta ekran birkaç kez titrer ve donar.
        Gerçek bir sistem donması hissi verir.

        Args:
            stdscr:    Curses penceresi
            intensity: Geçersiz kılma değeri
        """
        lvl = intensity if intensity is not None else self.intensity

        # Frame düşürme olasılığı
        drop_prob = lvl * 0.25
        if random.random() > drop_prob:
            return

        try:
            # Donma süresi
            freeze_dur = random.uniform(0.04, 0.2 * lvl + 0.05)
            time.sleep(freeze_dur)

            # Çözülme titremesi
            num_twitches = random.randint(1, int(lvl * 4) + 1)
            for _ in range(num_twitches):
                stdscr.chgat(0, 0, -1, curses.A_REVERSE)
                stdscr.refresh()
                time.sleep(0.015)
                stdscr.chgat(0, 0, -1, curses.A_NORMAL)
                stdscr.refresh()
                time.sleep(0.01)
        except Exception:
            pass

    def old_tv_noise(self, stdscr, intensity: Optional[float] = None) -> None:
        """
        Eski televizyon paraziti — dikey bant gürültüsü.

        Ekranda dikey şeritler halinde gürültü oluşturur.
        60'lar-70'ler anteni olmayan TV görüntüsünü simüle eder.

        Args:
            stdscr:    Curses penceresi
            intensity: Geçersiz kılma değeri
        """
        lvl = intensity if intensity is not None else self.intensity
        if lvl < 0.2:
            return

        h, w = self._safe_size(stdscr)

        # Gürültü bantlarının sayısı ve genişliği
        num_bands = random.randint(1, max(1, int(lvl * 4)))

        for _ in range(num_bands):
            bx = random.randint(0, w - 5)
            bw_size = random.randint(2, max(3, int(lvl * 8)))

            # Bant yoğunluğu
            band_density = random.uniform(0.3, 0.8)

            for y in range(h):
                if random.random() > band_density:
                    continue
                for dx in range(bw_size):
                    cx = bx + dx
                    if cx >= w - 1:
                        break
                    char = random.choice(STATIC_CHARS)
                    try:
                        attr = curses.color_pair(1) | curses.A_DIM
                        if random.random() > 0.7:
                            attr = curses.color_pair(5) | curses.A_BOLD
                        stdscr.addch(y, cx, char, attr)
                    except (curses.error, ValueError, OverflowError):
                        pass

    def crt_distortion(self, stdscr, intensity: Optional[float] = None) -> None:
        """
        CRT ekran bükülmesi — köşelerde karartma ve eğrilme.

        Eski tüp ekranların köşe karartması ve geometrik bozulmasını simüle eder.
        Sadece yüksek yoğunlukta belirgin hale gelir.

        Args:
            stdscr:    Curses penceresi
            intensity: Geçersiz kılma değeri
        """
        lvl = intensity if intensity is not None else self.intensity
        if lvl < 0.35:
            return

        h, w = self._safe_size(stdscr)

        # Köşe karartma mesafesi
        corner_size = max(1, int(lvl * 4))

        # Sol üst ve sağ üst köşeler
        for y in range(corner_size):
            dark_width = corner_size - y
            # Sol
            for x in range(dark_width):
                try:
                    stdscr.chgat(y, x, 1, curses.A_DIM)
                except curses.error:
                    pass
            # Sağ
            for x in range(w - dark_width, w):
                try:
                    stdscr.chgat(y, x, 1, curses.A_DIM)
                except curses.error:
                    pass

        # Sol alt ve sağ alt köşeler
        for y in range(h - corner_size, h):
            dark_width = corner_size - (h - 1 - y)
            for x in range(dark_width):
                try:
                    stdscr.chgat(y, x, 1, curses.A_DIM)
                except curses.error:
                    pass
            for x in range(max(0, w - dark_width), w):
                try:
                    stdscr.chgat(y, x, 1, curses.A_DIM)
                except curses.error:
                    pass

    # ──────────────────────────────────────────────────────────────────────────
    # KOMBİNE UYGULAMA
    # ──────────────────────────────────────────────────────────────────────────

    def apply_all(self, stdscr) -> None:
        """
        Mevcut yoğunluğa göre tüm glitch efektlerini uygular.

        Eşik değerleri:
          0.0 → 0.05 : Hiçbir şey
          0.05→ 0.15 : Hafif CRT gürültüsü
          0.15→ 0.30 : + Tarama çizgisi
          0.30→ 0.45 : + Eski TV paraziti
          0.45→ 0.60 : + Ekran kırılması
          0.60→ 0.75 : + Yatay yırtılma + CRT bükülmesi
          0.75→ 0.90 : + Frame düşürme
          0.90→ 1.00 : + Rastgele titreme (maksimum kaos)
        """
        lvl = self.intensity

        # Temel CRT gürültüsü
        if lvl >= 0.05:
            self.crt_noise(stdscr)

        # Tarama çizgisi
        if lvl >= 0.15:
            self.scanline_effect(stdscr)

        # Eski TV paraziti
        if lvl >= 0.30:
            self.old_tv_noise(stdscr)

        # Ekran kırılması
        if lvl >= 0.45:
            self.screen_break(stdscr)

        # Yatay yırtılma + CRT bükülmesi
        if lvl >= 0.60:
            self.horizontal_tear(stdscr)
            self.crt_distortion(stdscr)

        # Frame düşürme
        if lvl >= 0.75:
            self.frame_drop(stdscr)

        # Maksimum kaos
        if lvl >= 0.90:
            self.random_flicker(stdscr)

        # Frame ilerlet
        self.tick()

    def apply_ctrlc_mode(self, stdscr) -> None:
        """
        CTRL+C modu için artırılmış glitch uygulama.
        Normal moda göre her efekt %30 daha yoğundur.
        """
        # Geçici yoğunluk artırımı
        original = self.intensity
        boosted = min(1.0, original * 1.35)
        self.intensity = boosted

        # Tüm efektleri uygula
        self.crt_noise(stdscr)
        self.scanline_effect(stdscr)

        if boosted >= 0.2:
            self.old_tv_noise(stdscr)
            self.screen_break(stdscr)

        if boosted >= 0.4:
            self.horizontal_tear(stdscr)

        if boosted >= 0.5:
            self.frame_drop(stdscr)
            self.random_flicker(stdscr)

        if boosted >= 0.6:
            self.crt_distortion(stdscr)
            # Ekstra blok bozulması
            self.screen_break(stdscr)

        # Yoğunluğu geri al
        self.intensity = original
        self.tick()

    # ──────────────────────────────────────────────────────────────────────────
    # ÖZEL EFEKTLER
    # ──────────────────────────────────────────────────────────────────────────

    def data_corruption_wave(self, stdscr) -> None:
        """
        Veri bozulma dalgası — ekranda yukarıdan aşağıya bozulma ilerler.
        Saldırı anlarında kullanılır.
        """
        h, w = self._safe_size(stdscr)
        wave_y = (self.frame * 3) % h

        for dy in range(4):
            y = (wave_y + dy) % h
            wave_intensity = 1.0 - (dy / 4.0)

            for x in range(0, w - 1, 2):
                if random.random() < wave_intensity * 0.6:
                    char = random.choice(HEAVY_GLITCH)
                    try:
                        attr = curses.color_pair(2) | curses.A_BOLD
                        stdscr.addch(y, x, char, attr)
                    except (curses.error, ValueError, OverflowError):
                        pass

    def memory_leak_visual(self, stdscr) -> None:
        """
        Bellek sızıntısı görsel efekti — ekrana rastgele adresler yazar.
        """
        h, w = self._safe_size(stdscr)
        num_addrs = int(self.intensity * 8)

        for _ in range(num_addrs):
            y = random.randint(0, h - 1)
            x = random.randint(0, max(0, w - 20))

            addr = f"0x{random.randint(0, 0xFFFFFFFF):08X}"
            try:
                attr = curses.color_pair(2) | curses.A_DIM
                stdscr.addstr(y, x, addr, attr)
            except (curses.error, ValueError):
                pass

    def reality_crack(self, stdscr, crack_y: int, crack_width: int = 40) -> None:
        """
        Gerçeklik çatlağı — belirli bir satırda dramatik bozulma.

        Args:
            stdscr:      Curses penceresi
            crack_y:     Çatlağın Y koordinatı
            crack_width: Çatlak genişliği
        """
        h, w = self._safe_size(stdscr)
        if crack_y >= h:
            crack_y = h - 1

        center_x = w // 2 - crack_width // 2
        center_x = max(0, min(center_x, w - crack_width))

        crack_chars = "│╱╲╳╴╵╶╷╸╹╺╻┃┇┋━┅┉═║╔╗╚╝╠╣╦╩╬"

        for i, ch in enumerate(
            "".join(random.choice(crack_chars) for _ in range(crack_width))
        ):
            cx = center_x + i
            if cx >= w - 1:
                break
            try:
                attr = curses.color_pair(7) | curses.A_BOLD
                stdscr.addch(crack_y, cx, ch, attr)
            except (curses.error, ValueError, OverflowError):
                pass


# ─── Hızlı Test ───────────────────────────────────────────────────────────────

def _test_glitch_engine():
    """Glitch motorunu test eder (curses ile)"""

    def _run(stdscr):
        curses.start_color()
        curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
        curses.init_pair(2, curses.COLOR_RED, curses.COLOR_BLACK)
        curses.init_pair(3, curses.COLOR_CYAN, curses.COLOR_BLACK)
        curses.init_pair(4, curses.COLOR_YELLOW, curses.COLOR_BLACK)
        curses.init_pair(5, curses.COLOR_WHITE, curses.COLOR_BLACK)
        curses.init_pair(6, curses.COLOR_MAGENTA, curses.COLOR_BLACK)
        curses.init_pair(7, curses.COLOR_WHITE, curses.COLOR_RED)
        curses.curs_set(0)

        ge = GlitchEngine()
        for i in range(100):
            ge.set_intensity(i / 100)
            stdscr.clear()
            stdscr.addstr(0, 0, f"Yoğunluk: {ge.intensity:.2f}  Frame: {ge.frame}")
            ge.apply_all(stdscr)
            stdscr.refresh()
            time.sleep(0.05)

    curses.wrapper(_run)


if __name__ == "__main__":
    print("GlitchEngine test başlatılıyor...")
    _test_glitch_engine()
    print("Test tamamlandı.")
