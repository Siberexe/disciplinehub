#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║     TERMİNAL PSİKOLOJİK SİMÜLASYON MOTORU — ANA GİRİŞ                     ║
║     main.py  |  Versiyon: 4.2.1  |  @LonySoraz                             ║
╚══════════════════════════════════════════════════════════════════════════════╝

Kullanım:
    python main.py

Gereksinimler:
    Python 3.7+
    mpv  (ses çalma)
    curses (Python standart kütüphanesi)

Linux ve Termux uyumlu.

Çalışma modu:
    Normal mod → 30 sahne → Lonu.mp3 loop
    CTRL+C     → 40 sahne → horror_bgm.mp3 + jumpscare.wav

Çıkış:
    Normal mod bitiminde veya CTRL+C modunun 40. sahnesinde temiz çıkış.
    Tüm mpv süreçleri sonlandırılır.
"""

import sys
import os
import curses
import signal
import time
import threading
import random
import locale

# ─── Yerel Ayarlar ──────────────────────────────────────────────────────────
# UTF-8 terminal için
try:
    locale.setlocale(locale.LC_ALL, "")
except Exception:
    pass

# ─── Proje Modülleri ─────────────────────────────────────────────────────────
from audio_engine import AudioManager
from scene_engine import SceneManager, TransitionManager
from glitch_engine import GlitchEngine

# ─── Versiyon ve Yazar ───────────────────────────────────────────────────────
VERSION     = "4.2.1"
AUTHOR      = "@LonySoraz"
AUTHOR_FULL = "Powered by @LonySoraz"

# ─── Ses Dosyası Yolları ─────────────────────────────────────────────────────
_BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR  = os.path.join(_BASE_DIR, "assets")

LONU_MP3    = os.path.join(ASSETS_DIR, "Lonu.mp3")
HORROR_BGM  = os.path.join(ASSETS_DIR, "horror_bgm.mp3")
JUMPSCARE   = os.path.join(ASSETS_DIR, "jumpscare.wav")
TV_STATIC   = os.path.join(ASSETS_DIR, "tv_static.wav")
TV_CLICK    = os.path.join(ASSETS_DIR, "tv_click.wav")

# ─── Renk Çiftleri (modül genelinde kullanılır) ──────────────────────────────
COLOR_GREEN_BLACK   = 1   # Normal terminal
COLOR_RED_BLACK     = 2   # Tehlike / Kritik
COLOR_CYAN_BLACK    = 3   # Bilgi
COLOR_YELLOW_BLACK  = 4   # Uyarı
COLOR_WHITE_BLACK   = 5   # Parlak metin
COLOR_MAGENTA_BLACK = 6   # Glitch / Mistik
COLOR_WHITE_RED     = 7   # Kritik ters
COLOR_BLACK_GREEN   = 8   # Statik (arka plan)

# ─── Global Durum ─────────────────────────────────────────────────────────────
_ctrl_c_triggered     = False
_ctrl_c_lock          = threading.Lock()
_engine_instance      = None


# ─── SIGINT İşleyici ──────────────────────────────────────────────────────────

def _global_sigint_handler(sig, frame):
    """
    CTRL+C sinyalini global düzeyde yakalar.

    İlk CTRL+C → Alternatif (korku) moda geç.
    İkinci CTRL+C (ctrlc modunda) → Yine de CTRL+C modu devam eder,
    programdan çıkış ise sadece ctrlc modu bitince olur.
    """
    global _ctrl_c_triggered

    with _ctrl_c_lock:
        if not _ctrl_c_triggered:
            _ctrl_c_triggered = True
            if _engine_instance is not None:
                _engine_instance.request_ctrlc_mode()
        # İkinci sinyal — modu zaten değiştirdik, sessizce geç


signal.signal(signal.SIGINT, _global_sigint_handler)
# SIGTERM'e de benzer işlem
signal.signal(signal.SIGTERM, _global_sigint_handler)


# ─── Ana Motor Sınıfı ─────────────────────────────────────────────────────────

class PsychSimEngine:
    """
    Terminal Psikolojik Simülasyon Motoru.

    İki çalışma modu:
      'normal' → 30 sahne, Lonu.mp3 loop
      'ctrlc'  → 40 sahne, horror_bgm.mp3 + jumpscare.wav

    CTRL+C:
      Lonu.mp3 TAMAMEN durdurulur (asla devam etmez).
      horror_bgm.mp3 başlatılır.
      jumpscare.wav geçişlerde oynatılır.
    """

    def __init__(self):
        # Alt modüller
        self.audio   = AudioManager()
        self.glitch  = GlitchEngine()

        # Curses penceresi (run() içinde ayarlanır)
        self.stdscr   = None

        # Mod durumu
        self.mode     = "normal"
        self._running = False

        # CTRL+C geçiş isteği (thread-safe)
        self._ctrlc_requested = False
        self._ctrlc_event     = threading.Event()

        # Sahne yöneticisi (mod başlatılınca oluşturulur)
        self._scene_mgr: SceneManager = None

    # ──────────────────────────────────────────────────────────────────────────
    # CTRL+C TETIKLEYICI
    # ──────────────────────────────────────────────────────────────────────────

    def request_ctrlc_mode(self) -> None:
        """
        CTRL+C modu geçişini ister.
        Thread-safe, sinyal işleyicisinden çağrılabilir.
        """
        self._ctrlc_requested = True
        self._ctrlc_event.set()

        # Aktif sahne yöneticisine de bildir
        if self._scene_mgr is not None:
            try:
                self._scene_mgr.timer.interrupt()
            except Exception:
                pass

    def is_ctrlc_requested(self) -> bool:
        """CTRL+C modu istenmiş mi?"""
        return self._ctrlc_requested

    # ──────────────────────────────────────────────────────────────────────────
    # CURSES BAŞLATMA
    # ──────────────────────────────────────────────────────────────────────────

    def _init_colors(self) -> None:
        """
        Curses renk çiftlerini başlatır.
        Terminal renk desteği yoksa (Termux eski sürüm) sessizce atlar.
        """
        try:
            if not curses.has_colors():
                return

            curses.start_color()

            # use_default_colors() — -1 arka plan için terminal varsayılanı kullanır
            try:
                curses.use_default_colors()
                bg = -1
            except Exception:
                bg = curses.COLOR_BLACK

            curses.init_pair(COLOR_GREEN_BLACK,   curses.COLOR_GREEN,   bg)
            curses.init_pair(COLOR_RED_BLACK,     curses.COLOR_RED,     bg)
            curses.init_pair(COLOR_CYAN_BLACK,    curses.COLOR_CYAN,    bg)
            curses.init_pair(COLOR_YELLOW_BLACK,  curses.COLOR_YELLOW,  bg)
            curses.init_pair(COLOR_WHITE_BLACK,   curses.COLOR_WHITE,   bg)
            curses.init_pair(COLOR_MAGENTA_BLACK, curses.COLOR_MAGENTA, bg)
            curses.init_pair(COLOR_WHITE_RED,     curses.COLOR_WHITE,   curses.COLOR_RED)
            curses.init_pair(COLOR_BLACK_GREEN,   curses.COLOR_BLACK,   curses.COLOR_GREEN)

        except Exception:
            pass  # Renk desteği yoksa da program çalışır

    def _setup_curses(self, stdscr) -> None:
        """Curses başlangıç ayarları"""
        self.stdscr = stdscr

        # İmleci gizle
        try:
            curses.curs_set(0)
        except Exception:
            pass

        # Tuş takımı aktif
        stdscr.keypad(True)

        # Zaman aşımı: 80ms (12 FPS getch)
        stdscr.timeout(80)

        # Renkler
        self._init_colors()

        # Temizle
        stdscr.clear()
        stdscr.refresh()

    # ──────────────────────────────────────────────────────────────────────────
    # BOYUT DEĞİŞİKLİĞİ
    # ──────────────────────────────────────────────────────────────────────────

    def _handle_resize(self) -> bool:
        """
        Terminal boyut değişikliğini algılar ve yeniden boyutlandırır.

        Returns:
            bool: Boyut değişti ise True
        """
        if self.stdscr is None:
            return False

        try:
            h, w = self.stdscr.getmaxyx()
            if curses.is_term_resized(h, w):
                curses.resizeterm(h, w)
                self.stdscr.clear()
                self.stdscr.refresh()
                return True
        except Exception:
            pass

        return False

    # ──────────────────────────────────────────────────────────────────────────
    # GİRİŞ EKRANI
    # ──────────────────────────────────────────────────────────────────────────

    def _show_intro_screen(self) -> None:
        """
        Başlangıç ekranını gösterir ve ENTER / zaman aşımı bekler.
        CTRL+C gelirse giriş ekranını atlar.
        """
        stdscr = self.stdscr
        max_y, max_x = stdscr.getmaxyx()

        ascii_logo = [
            r" ________  _______   ________  _____ ______      ",
            r"|        ||       \ |        \|     \  \   |     ",
            r"   | |   |  ──────  |  ──────  | |\ \  \  |     ",
            r"   | |   |  ──────  |  ──────  | | \ \  \ |     ",
            r"   |_|   |_______/  |________| |_|  \_\  \|     ",
        ]

        sub_lines = [
            "",
            "  PSİKOLOJİK SİMÜLASYON MOTORU",
            f"  Versiyon {VERSION}",
            "",
            "  ┌────────────────────────────────────────┐",
            "  │  30 sahne  │  Normal mod                │",
            "  │  40 sahne  │  CTRL+C modu               │",
            "  │  Ses       │  mpv gerekli               │",
            "  └────────────────────────────────────────┘",
            "",
            "  [ BAŞLAMAK İÇİN ENTER VEYA BOŞLUK ]",
            "",
            f"  {AUTHOR_FULL}",
        ]

        # Tüm satırlar
        all_lines = ascii_logo + sub_lines

        stdscr.clear()
        start_y = max(0, (max_y - len(all_lines)) // 2)

        for i, line in enumerate(all_lines):
            y = start_y + i
            if y >= max_y - 1:
                break

            x = max(1, (max_x - len(line)) // 2)

            try:
                if i < len(ascii_logo):
                    # ASCII logo — yeşil bold
                    attr = curses.color_pair(COLOR_GREEN_BLACK) | curses.A_BOLD
                elif "PSİKOLOJİK" in line or "Versiyon" in line:
                    attr = curses.color_pair(COLOR_CYAN_BLACK) | curses.A_BOLD
                elif "ENTER" in line or "BOŞLUK" in line:
                    attr = curses.color_pair(COLOR_YELLOW_BLACK) | curses.A_BOLD
                    if (int(time.time() * 2) % 2) == 0:
                        attr |= curses.A_REVERSE
                elif "Powered" in line or AUTHOR in line:
                    attr = curses.color_pair(COLOR_MAGENTA_BLACK) | curses.A_DIM
                elif "┌" in line or "└" in line or "│" in line or "─" in line:
                    attr = curses.color_pair(COLOR_GREEN_BLACK)
                else:
                    attr = curses.color_pair(COLOR_WHITE_BLACK) | curses.A_DIM

                stdscr.addstr(y, x, line[:max_x - x - 1], attr)
            except curses.error:
                pass

        # Küçük glitch efekti
        for _ in range(3):
            gx = random.randint(1, max(1, max_x - 20))
            gy = random.randint(start_y, start_y + len(all_lines))
            if gy < max_y - 1:
                try:
                    noise = "".join(random.choice("░▒▓") for _ in range(5))
                    stdscr.addstr(gy, gx, noise,
                                  curses.color_pair(COLOR_GREEN_BLACK) | curses.A_DIM)
                except curses.error:
                    pass

        stdscr.refresh()

        # Tuş bekleme (5 saniye timeout veya ENTER)
        stdscr.timeout(200)
        waited = 0
        max_wait = 5000  # ms

        while waited < max_wait:
            if self._ctrlc_requested:
                break
            key = stdscr.getch()
            if key in (
                ord("\n"), ord("\r"), ord(" "),
                curses.KEY_ENTER, curses.KEY_BACKSPACE, -1
            ):
                if key != -1:
                    break
            waited += 200

        stdscr.timeout(80)

    # ──────────────────────────────────────────────────────────────────────────
    # NORMAL MOD
    # ──────────────────────────────────────────────────────────────────────────

    def _run_normal_mode(self) -> None:
        """
        Normal modu çalıştırır.

        - Lonu.mp3 döngüde çalar
        - 30 sahne sırayla oynatılır
        - Her sahne arası TV statik geçişi
        - CTRL+C gelirse Lonu.mp3 TAMAMEN durur ve fonksiyon döner
        """
        self.mode = "normal"

        # ── Lonu.mp3 başlat ──
        self.audio.play_music(LONU_MP3, loop=True, volume=54)

        # ── Sahne yöneticisi ──
        self._scene_mgr = SceneManager(
            stdscr=self.stdscr,
            audio_manager=self.audio,
            glitch_engine=self.glitch,
            mode="normal",
        )

        # ── 30 Sahne Döngüsü ──
        for scene_idx in range(30):
            # Boyut kontrolü
            self._handle_resize()

            # CTRL+C kontrolü
            if self._ctrlc_requested:
                break

            # Sahneyi çalıştır
            self._scene_mgr.run_scene(scene_idx)

            # CTRL+C kontrolü (sahne sonrası)
            if self._ctrlc_requested:
                break

            # Son sahne değilse geçiş efekti
            if scene_idx < 29:
                self._scene_mgr.transition.play_transition(intense=False)

        # ── Lonu.mp3 TAMAMEN durdur ──
        # Normal mod bitti veya CTRL+C tetiklendi — her iki durumda da durdur
        self.audio.stop_music()
        time.sleep(0.15)  # Tamamen kapandığından emin ol

    # ──────────────────────────────────────────────────────────────────────────
    # CTRL+C MOD
    # ──────────────────────────────────────────────────────────────────────────

    def _run_ctrlc_mode(self) -> None:
        """
        CTRL+C modunu çalıştırır.

        Kurallar:
          - Lonu.mp3 KESİNLİKLE ÇALMAZ (önceden durdurulmuş)
          - horror_bgm.mp3 döngüde çalar
          - jumpscare.wav geçişlerde oynatılır
          - 40 sahne sırayla oynatılır
          - Program bu fonksiyon bitince sona erer
        """
        self.mode = "ctrlc"

        # Emin olalım — Lonu.mp3 ÇALMIYOR
        self.audio.stop_music()
        time.sleep(0.25)

        # ── CTRL+C Giriş Efekti ──
        self._ctrlc_intro_effect()

        # ── horror_bgm.mp3 başlat ──
        self.audio.play_music(HORROR_BGM, loop=True, volume=70)
        time.sleep(0.3)

        # ── İlk Jumpscare ──
        self.audio.play_sfx(JUMPSCARE, volume=95)

        # ── Sahne yöneticisi ──
        self._scene_mgr = SceneManager(
            stdscr=self.stdscr,
            audio_manager=self.audio,
            glitch_engine=self.glitch,
            mode="ctrlc",
        )

        # ── 40 Sahne Döngüsü ──
        for scene_idx in range(40):
            self._handle_resize()
            self._scene_mgr.run_scene(scene_idx)

            # Son sahne değilse geçiş
            if scene_idx < 39:
                self._scene_mgr.transition.play_transition(intense=True)

            # Periyodik jumpscare (8, 16, 24, 32. sahnelerde)
            if scene_idx > 0 and scene_idx % 8 == 0 and scene_idx < 39:
                self.audio.play_sfx(JUMPSCARE, volume=85)

        # ── Final ──
        self._ctrlc_final_screen()

    # ──────────────────────────────────────────────────────────────────────────
    # CTRL+C GİRİŞ EFEKTİ
    # ──────────────────────────────────────────────────────────────────────────

    def _ctrlc_intro_effect(self) -> None:
        """
        CTRL+C moduna geçiş dramatik efekti.

        - Kırmızı statik flaş
        - Uyarı metni
        - Titreme
        """
        stdscr = self.stdscr
        max_y, max_x = stdscr.getmaxyx()

        # Kırmızı statik
        self.glitch.static_flash(stdscr, duration=0.6, color_pair=COLOR_RED_BLACK)

        # Uyarı metni
        warning_lines = [
            "",
            "  ██╗  ██╗ █████╗ ████████╗ █████╗     ██╗   ██╗ █████╗ ██████╗  ",
            "  ██║  ██║██╔══██╗╚══██╔══╝██╔══██╗    ╚██╗ ██╔╝██╔══██╗██╔══██╗ ",
            "  ███████║███████║   ██║   ███████║     ╚████╔╝ ███████║██████╔╝  ",
            "  ██╔══██║██╔══██║   ██║   ██╔══██║      ╚██╔╝  ██╔══██║██╔═══╝  ",
            "  ██║  ██║██║  ██║   ██║   ██║  ██║       ██║   ██║  ██║██║      ",
            "  ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝       ╚═╝   ╚═╝  ╚═╝╚═╝      ",
            "",
            "         BU HAREKET KAYIT ALTINA ALINDI.",
            "",
            "              SİSTEM YANIT VERİYOR...",
            "",
            "         Çıkış yolu aramak işe yaramaz.",
            "",
        ]

        stdscr.clear()
        start_y = max(0, (max_y - len(warning_lines)) // 2)

        for i, line in enumerate(warning_lines):
            y = start_y + i
            if y >= max_y - 1:
                break
            x = max(1, (max_x - len(line)) // 2)

            try:
                attr = curses.color_pair(COLOR_RED_BLACK) | curses.A_BOLD
                stdscr.addstr(y, x, line[:max_x - x - 1], attr)
            except curses.error:
                pass

        stdscr.refresh()
        time.sleep(2.0)

        # Titreme
        for _ in range(4):
            try:
                stdscr.chgat(0, 0, -1, curses.A_REVERSE)
                stdscr.refresh()
                time.sleep(0.06)
                stdscr.chgat(0, 0, -1, curses.A_NORMAL)
                stdscr.refresh()
                time.sleep(0.04)
            except Exception:
                pass

        # Kısa statik
        self.glitch.static_flash(stdscr, duration=0.4, color_pair=COLOR_RED_BLACK)

    # ──────────────────────────────────────────────────────────────────────────
    # CTRL+C FİNAL
    # ──────────────────────────────────────────────────────────────────────────

    def _ctrlc_final_screen(self) -> None:
        """
        CTRL+C modu final ekranı.

        - Tüm sesler durdurulur
        - Ekran karartılır
        - Final mesajı gösterilir
        """
        stdscr = self.stdscr

        # TÜM SESLERİ DURDUR
        self.audio.stop_all()
        time.sleep(0.3)

        # Ekran karartması
        try:
            stdscr.clear()
            stdscr.refresh()
        except Exception:
            pass

        time.sleep(0.5)

        # Final mesajı
        max_y, max_x = stdscr.getmaxyx()
        shutdown_sequence = [
            "[    ] Tüm ses süreçleri sonlandırılıyor...",
            "[    ] mpv süreçleri kapatıldı.",
            "[    ] Kayıt dosyaları silindi.",
            "[    ] Bağlantılar kesildi.",
            "[OK  ] Temiz çıkış hazır.",
            "",
            "       BU BİR SİMÜLASYONDU.",
            "",
            f"       {AUTHOR_FULL}",
        ]

        center_y = max(0, (max_y - len(shutdown_sequence)) // 2)

        for i, msg in enumerate(shutdown_sequence):
            y = center_y + i
            if y >= max_y - 1:
                break

            x = max(1, (max_x - len(msg)) // 2)

            try:
                attr = curses.color_pair(COLOR_GREEN_BLACK)
                if "OK" in msg:
                    attr = curses.color_pair(COLOR_GREEN_BLACK) | curses.A_BOLD
                elif "SİMÜLASYON" in msg:
                    attr = curses.color_pair(COLOR_CYAN_BLACK) | curses.A_BOLD
                elif AUTHOR in msg:
                    attr = curses.color_pair(COLOR_MAGENTA_BLACK)

                stdscr.addstr(y, x, msg[:max_x - x - 1], attr)
                stdscr.refresh()
                time.sleep(0.25)
            except (curses.error, ValueError):
                pass

        time.sleep(2.0)

    # ──────────────────────────────────────────────────────────────────────────
    # NORMAL MOD FİNAL (Sahne 30 bittikten sonra)
    # ──────────────────────────────────────────────────────────────────────────

    def _normal_mode_outro(self) -> None:
        """
        Normal mod bitiş efekti — ekran solma.
        Sahne 30'dan sonra gösterilir.
        """
        stdscr = self.stdscr

        # Müzik kapat
        self.audio.stop_all()
        time.sleep(0.2)

        # Yavaş karartma
        try:
            max_y, max_x = stdscr.getmaxyx()
            for step in range(5):
                try:
                    stdscr.chgat(0, 0, -1, curses.A_DIM)
                    stdscr.refresh()
                    time.sleep(0.15)
                except Exception:
                    pass
        except Exception:
            pass

        # Ekran temizle
        try:
            stdscr.clear()
            stdscr.refresh()
        except Exception:
            pass

        time.sleep(0.5)

    # ──────────────────────────────────────────────────────────────────────────
    # TEMIZ ÇIKIŞ
    # ──────────────────────────────────────────────────────────────────────────

    def _clean_exit(self) -> None:
        """
        Temiz çıkış — tüm ses süreçlerini durdurur.
        Program kapanmadan önce çağrılmalıdır.
        """
        try:
            self.audio.stop_all()
        except Exception:
            pass

        self._running = False

    # ──────────────────────────────────────────────────────────────────────────
    # ANA ÇALIŞMA FONKSİYONU
    # ──────────────────────────────────────────────────────────────────────────

    def run(self, stdscr) -> None:
        """
        curses.wrapper() tarafından çağrılan ana fonksiyon.

        Args:
            stdscr: Curses ana penceresi
        """
        global _engine_instance
        _engine_instance = self

        self._setup_curses(stdscr)
        self._running = True

        try:
            # Giriş ekranı
            self._show_intro_screen()

            if self._ctrlc_requested:
                # Giriş ekranında CTRL+C — doğrudan ctrlc moduna
                self._run_ctrlc_mode()
            else:
                # Normal modu çalıştır
                self._run_normal_mode()

                if self._ctrlc_requested:
                    # Normal mod sırasında CTRL+C geldi — ctrlc moduna geç
                    self._run_ctrlc_mode()
                else:
                    # Normal mod doğal olarak bitti — outro göster
                    self._normal_mode_outro()

        except Exception as e:
            # Beklenmeyen hata — temizlik yap
            self._clean_exit()
            raise
        finally:
            self._clean_exit()


# ─── Bağımlılık Kontrolü ─────────────────────────────────────────────────────

def _check_dependencies() -> None:
    """
    Gerekli araçları kontrol eder.
    mpv yoksa uyarı verir (program ses olmadan da çalışır).
    """
    import shutil

    issues = []

    # Python sürümü
    if sys.version_info < (3, 7):
        issues.append(f"Python 3.7+ gerekli. Mevcut: {sys.version}")

    # mpv
    if not shutil.which("mpv"):
        mpv_available = False
        # ffplay alternatif
        if not shutil.which("ffplay"):
            issues.append(
                "Ses oynatıcı bulunamadı!\n"
                "  Termux: pkg install mpv\n"
                "  Linux:  sudo apt install mpv"
            )
    else:
        mpv_available = True

    # Varlık dizini
    if not os.path.isdir(ASSETS_DIR):
        issues.append(f"assets/ dizini bulunamadı: {ASSETS_DIR}")

    # Varlık dosyaları kontrolü
    required_files = {
        LONU_MP3:   "Lonu.mp3 (kendi müziğinizi ekleyin)",
        HORROR_BGM: "horror_bgm.mp3 (kendi müziğinizi ekleyin)",
        JUMPSCARE:  "jumpscare.wav",
        TV_STATIC:  "tv_static.wav",
        TV_CLICK:   "tv_click.wav",
    }

    for fpath, desc in required_files.items():
        if not os.path.isfile(fpath):
            issues.append(f"Ses dosyası eksik: {os.path.basename(fpath)} ({desc})")

    # Uyarıları göster
    if issues:
        print("\n" + "═" * 60)
        print("UYARI — EKSİK BAĞIMLILIKLAR")
        print("═" * 60)
        for issue in issues:
            print(f"  ⚠  {issue}")
        print("═" * 60)
        print("  Program çalışmaya devam edecek ama ses olmayabilir.")
        print("  Ses dosyaları için: python generate_assets.py")
        print("═" * 60 + "\n")
        time.sleep(2)


# ─── Uygulama Başlatma ────────────────────────────────────────────────────────

def _show_terminal_banner() -> None:
    """Terminale ASCII banner yazdırır"""
    banner = f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║     TERMİNAL PSİKOLOJİK SİMÜLASYON MOTORU  v{VERSION}                        ║
║                                                                              ║
║     Mod 1 (Normal): 30 sahne  |  Lonu.mp3                                  ║
║     Mod 2 (CTRL+C): 40 sahne  |  horror_bgm.mp3 + jumpscare.wav            ║
║                                                                              ║
║     Başlamak için program çalışacak.                                        ║
║     CTRL+C → Korku modu tetiklenir.                                         ║
║                                                                              ║
║     {AUTHOR_FULL:<72} ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
    """
    print(banner)


def main() -> None:
    """
    Uygulama ana giriş noktası.

    1. Bağımlılık kontrolü
    2. PsychSimEngine başlat
    3. curses.wrapper ile çalıştır
    4. Temiz çıkış
    """
    # ── Terminal banner ──
    _show_terminal_banner()

    # ── Bağımlılık kontrolü ──
    _check_dependencies()

    # ── Motor oluştur ──
    engine = PsychSimEngine()

    # ── Çalıştır ──
    exit_code = 0
    try:
        curses.wrapper(engine.run)

    except KeyboardInterrupt:
        # curses dışında CTRL+C — temizlik yeterli
        pass

    except curses.error as e:
        # Curses hatası — terminal çok küçük vs.
        print(f"\n[HATA] Curses hatası: {e}", file=sys.stderr)
        print("Terminal en az 80x24 olmalıdır.", file=sys.stderr)
        exit_code = 1

    except Exception as e:
        print(f"\n[HATA] Beklenmeyen hata: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        exit_code = 1

    finally:
        # ── Her durumda temizlik ──
        try:
            engine.audio.stop_all()
        except Exception:
            pass

        # Terminal durumunu onar (curses bazen bırakır)
        try:
            curses.endwin()
        except Exception:
            pass

        print(f"\n{'═' * 60}")
        print("  TERMİNAL PSİKOLOJİK SİMÜLASYON MOTORU KAPATILDI")
        print(f"  {AUTHOR_FULL}")
        print(f"{'═' * 60}\n")

    sys.exit(exit_code)


# ─── Giriş Noktası ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    main()
