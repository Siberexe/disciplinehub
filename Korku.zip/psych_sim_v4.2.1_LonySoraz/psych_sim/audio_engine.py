#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║          TERMİNAL PSİKOLOJİK SİMÜLASYON MOTORU — SES MOTORU               ║
║          audio_engine.py  |  Versiyon: 4.2.1  |  @LonySoraz               ║
╚══════════════════════════════════════════════════════════════════════════════╝

Bu modül tüm ses işlemlerini yönetir:
  - Arka plan müziği çalma / durdurma (mpv tabanlı)
  - Ses efektleri (SFX) çalma (eş zamanlı)
  - Tüm sesleri durdurma ve süreç temizliği
  - Orphan (sahipsiz) süreç koruması
  - mpv → ffplay → aplay yedek zinciri

Linux ve Termux uyumlu.
"""

import os
import signal
import subprocess
import threading
import time
import logging
import shutil
from typing import Optional, List

# ─── Günlük Kaydı ─────────────────────────────────────────────────────────────
logger = logging.getLogger(__name__)

# ─── Sabitler ─────────────────────────────────────────────────────────────────

# Ses oynatıcı arama öncelik listesi
PLAYER_PRIORITY = ["mpv", "ffplay", "aplay", "cvlc"]

# mpv varsayılan argümanları
MPV_BASE_ARGS = [
    "--no-video",
    "--really-quiet",
    "--no-config",
    "--no-terminal",
]

# ffplay varsayılan argümanları
FFPLAY_BASE_ARGS = [
    "-nodisp",
    "-loglevel", "quiet",
    "-hide_banner",
]

# ─── Yardımcı Fonksiyonlar ────────────────────────────────────────────────────

def _find_player() -> Optional[str]:
    """
    Sistemde mevcut ses oynatıcısını bulur.
    Öncelik sırası: mpv > ffplay > aplay > cvlc

    Returns:
        str: Bulunan oynatıcının yolu, yoksa None
    """
    for player in PLAYER_PRIORITY:
        path = shutil.which(player)
        if path:
            logger.debug(f"Ses oynatıcı bulundu: {path}")
            return player
    logger.warning("Hiçbir ses oynatıcı bulunamadı! Ses devre dışı.")
    return None


def _kill_process_safe(proc: subprocess.Popen) -> None:
    """
    Bir süreci güvenli biçimde sonlandırır.
    Önce SIGTERM gönderir, 2 saniye bekler, hâlâ çalışıyorsa SIGKILL kullanır.

    Args:
        proc: Sonlandırılacak Popen nesnesi
    """
    if proc is None:
        return

    try:
        # Önce süreç grubunu sonlandırmayı dene
        pgid = os.getpgid(proc.pid)
        os.killpg(pgid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError, OSError):
        try:
            proc.terminate()
        except Exception:
            pass

    # Kapanmasını bekle
    try:
        proc.wait(timeout=2.0)
    except subprocess.TimeoutExpired:
        # Zorla kapat
        try:
            pgid = os.getpgid(proc.pid)
            os.killpg(pgid, signal.SIGKILL)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        try:
            proc.wait(timeout=1.0)
        except Exception:
            pass
    except Exception:
        pass


# ─── AudioManager Sınıfı ──────────────────────────────────────────────────────

class AudioManager:
    """
    Terminal Psikolojik Simülasyon Motoru — Ses Yöneticisi

    Görevler:
      • Arka plan müziğini döngüde çalar (play_music)
      • Müziği tamamen durdurur (stop_music) — hiçbir süreç kalmaz
      • Ses efektlerini eş zamanlı oynatır (play_sfx)
      • Tüm sesleri durdurur, süreçleri temizler (stop_all)

    Thread-safe tasarım: tüm kritik bölümler kilit (Lock) ile korunur.
    """

    def __init__(self):
        # Arka plan müziği süreci
        self._music_proc: Optional[subprocess.Popen] = None
        self._music_lock = threading.Lock()
        self._current_music_file: Optional[str] = None

        # SFX süreçleri listesi
        self._sfx_procs: List[subprocess.Popen] = []
        self._sfx_lock = threading.Lock()

        # Sistemde mevcut oynatıcı
        self._player = _find_player()

        # Toplam çalınan ses sayısı (istatistik)
        self._play_count = 0
        self._sfx_count = 0

        logger.info(f"AudioManager başlatıldı. Oynatıcı: {self._player}")

    # ──────────────────────────────────────────────────────────────────────────
    # KAMU API
    # ──────────────────────────────────────────────────────────────────────────

    def play_music(self, filepath: str, loop: bool = True, volume: int = 70) -> bool:
        """
        Arka plan müziğini çalar.

        Mevcut müzik varsa önce durdurulur, ardından yeni dosya başlatılır.
        Dosya mevcut değilse işlem sessizce atlanır.

        Args:
            filepath: Ses dosyasının tam yolu
            loop:     True ise sonsuz döngüde çalar
            volume:   0-100 arası ses seviyesi

        Returns:
            bool: Başarılıysa True
        """
        # Önceki müziği durdur
        self.stop_music()

        # Dosya kontrolü
        if not os.path.isfile(filepath):
            logger.warning(f"Müzik dosyası bulunamadı: {filepath}")
            return False

        if self._player is None:
            logger.warning("Ses oynatıcı yok, müzik atlanıyor.")
            return False

        proc = self._build_music_process(filepath, loop, volume)
        if proc is None:
            return False

        with self._music_lock:
            self._music_proc = proc
            self._current_music_file = filepath
            self._play_count += 1

        logger.info(f"Müzik başlatıldı: {os.path.basename(filepath)} (döngü={loop})")
        return True

    def stop_music(self) -> None:
        """
        Arka plan müziğini tamamen durdurur.

        Süreç ve tüm alt süreçleri sonlandırılır.
        Bu fonksiyon çağrıldıktan sonra hiçbir müzik süreci kalmaz.
        """
        with self._music_lock:
            if self._music_proc is not None:
                _kill_process_safe(self._music_proc)
                self._music_proc = None
                self._current_music_file = None
                logger.debug("Müzik durduruldu.")

    def play_sfx(self, filepath: str, volume: int = 80, blocking: bool = False) -> None:
        """
        Ses efekti çalar.

        Varsayılan olarak eş zamanlı (non-blocking) çalışır.
        Arka planda bir thread başlatır; müziği etkilemez.

        Args:
            filepath: Ses dosyasının tam yolu
            volume:   0-100 arası ses seviyesi
            blocking: True ise tamamlanana kadar bekler
        """
        if not os.path.isfile(filepath):
            logger.warning(f"SFX dosyası bulunamadı: {filepath}")
            return

        if self._player is None:
            return

        if blocking:
            self._play_sfx_sync(filepath, volume)
        else:
            t = threading.Thread(
                target=self._play_sfx_sync,
                args=(filepath, volume),
                daemon=True,
                name=f"sfx-{os.path.basename(filepath)}"
            )
            t.start()

    def stop_all(self) -> None:
        """
        Tüm sesleri (müzik + SFX) durdurur.

        Bu fonksiyon program kapanırken çağrılmalıdır.
        Tüm mpv süreçlerini zorla sonlandırır.
        """
        # Müziği durdur
        self.stop_music()

        # SFX süreçlerini durdur
        with self._sfx_lock:
            for proc in self._sfx_procs[:]:
                _kill_process_safe(proc)
            self._sfx_procs.clear()

        # Sistemde kalan tüm mpv/ffplay süreçlerini temizle
        self._kill_orphan_players()

        logger.info("Tüm ses süreçleri sonlandırıldı.")

    def is_music_playing(self) -> bool:
        """Müzik çalıyor mu kontrol eder"""
        with self._music_lock:
            if self._music_proc is None:
                return False
            # Süreç hâlâ çalışıyor mu?
            return self._music_proc.poll() is None

    def get_current_music(self) -> Optional[str]:
        """Şu an çalan müzik dosyasının adını döner"""
        with self._music_lock:
            if self._current_music_file:
                return os.path.basename(self._current_music_file)
            return None

    def get_stats(self) -> dict:
        """Ses istatistiklerini döner"""
        return {
            "player": self._player,
            "music_playing": self.is_music_playing(),
            "current_music": self.get_current_music(),
            "total_music_played": self._play_count,
            "total_sfx_played": self._sfx_count,
            "active_sfx_count": len(self._sfx_procs),
        }

    # ──────────────────────────────────────────────────────────────────────────
    # ÖZEL YARDIMCI METODLAR
    # ──────────────────────────────────────────────────────────────────────────

    def _build_music_process(
        self, filepath: str, loop: bool, volume: int
    ) -> Optional[subprocess.Popen]:
        """
        Müzik çalmak için Popen süreci oluşturur.
        Oynatıcıya göre uygun argümanları seçer.
        """
        player = self._player
        cmd = []

        if player == "mpv":
            cmd = [
                "mpv",
                *MPV_BASE_ARGS,
                f"--volume={volume}",
            ]
            if loop:
                cmd.append("--loop=inf")
            cmd.append(filepath)

        elif player == "ffplay":
            cmd = [
                "ffplay",
                *FFPLAY_BASE_ARGS,
                "-volume", str(volume),
            ]
            if loop:
                cmd.extend(["-loop", "0"])
            else:
                cmd.append("-autoexit")
            cmd.append(filepath)

        elif player == "aplay":
            # aplay yalnızca WAV destekler, döngü desteği yoktur
            cmd = ["aplay", "-q", filepath]

        elif player == "cvlc":
            cmd = ["cvlc", "--intf", "dummy", f"--gain={volume/100:.2f}"]
            if loop:
                cmd.extend(["--loop"])
            cmd.append(filepath)
        else:
            return None

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                preexec_fn=os.setsid,   # Yeni süreç grubu — temiz öldürme için
            )
            return proc
        except (FileNotFoundError, PermissionError, OSError) as e:
            logger.error(f"Müzik süreci başlatılamadı: {e}")
            return None

    def _play_sfx_sync(self, filepath: str, volume: int) -> None:
        """
        Ses efektini eş zamanlı çalar (iç kullanım).
        Çalma bittikten sonra süreci listeden kaldırır.
        """
        player = self._player
        cmd = []

        if player == "mpv":
            cmd = [
                "mpv",
                *MPV_BASE_ARGS,
                f"--volume={volume}",
                filepath,
            ]
        elif player == "ffplay":
            cmd = [
                "ffplay",
                *FFPLAY_BASE_ARGS,
                "-autoexit",
                "-volume", str(volume),
                filepath,
            ]
        elif player == "aplay":
            cmd = ["aplay", "-q", filepath]
        elif player == "cvlc":
            cmd = ["cvlc", "--intf", "dummy", "--play-and-exit",
                   f"--gain={volume/100:.2f}", filepath]
        else:
            return

        proc = None
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                preexec_fn=os.setsid,
            )

            with self._sfx_lock:
                self._sfx_procs.append(proc)
                self._sfx_count += 1

            proc.wait()

        except Exception as e:
            logger.debug(f"SFX çalma hatası: {e}")
        finally:
            if proc is not None:
                with self._sfx_lock:
                    if proc in self._sfx_procs:
                        self._sfx_procs.remove(proc)

    def _kill_orphan_players(self) -> None:
        """
        Sistemde kalan sahipsiz oynatıcı süreçlerini temizler.
        pkill komutu kullanılır — hata olursa sessizce geçilir.
        """
        for player_name in ["mpv", "ffplay"]:
            try:
                subprocess.run(
                    ["pkill", "-9", "-f", player_name],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=3,
                )
            except Exception:
                pass

    def __del__(self):
        """Nesne yok edilirken temizlik yapar"""
        try:
            self.stop_all()
        except Exception:
            pass


# ─── SFX Kuyruk Yöneticisi (bonus modül) ─────────────────────────────────────

class SFXQueue:
    """
    Ses efektleri için sıralı kuyruk yöneticisi.
    Aynı anda çok sayıda SFX tetiklendiğinde düzenli çalmayı sağlar.
    """

    def __init__(self, audio_manager: AudioManager, max_concurrent: int = 3):
        """
        Args:
            audio_manager:  Ana AudioManager nesnesi
            max_concurrent: Aynı anda çalabilecek maksimum SFX sayısı
        """
        self._am = audio_manager
        self._max = max_concurrent
        self._active = 0
        self._lock = threading.Lock()

    def play(self, filepath: str, volume: int = 80) -> bool:
        """
        SFX'i kuyruğa alır ve müsaitse çalar.

        Returns:
            bool: Çalma başlatıldıysa True
        """
        with self._lock:
            if self._active >= self._max:
                return False
            self._active += 1

        def _wrapped():
            try:
                self._am.play_sfx(filepath, volume, blocking=True)
            finally:
                with self._lock:
                    self._active -= 1

        t = threading.Thread(target=_wrapped, daemon=True)
        t.start()
        return True


# ─── Modül Test Bloğu ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    print("AudioManager modül testi başlatılıyor...")

    am = AudioManager()
    stats = am.get_stats()
    print(f"Oynatıcı: {stats['player']}")
    print(f"İstatistikler: {stats}")

    # Var olan bir WAV dosyası ile test
    test_wav = "/tmp/test_audio.wav"
    if os.path.exists(test_wav):
        print(f"Test dosyası çalınıyor: {test_wav}")
        am.play_sfx(test_wav, volume=50, blocking=True)
        print("Tamamlandı.")
    else:
        print("Test WAV dosyası bulunamadı, ses testi atlandı.")

    am.stop_all()
    print("AudioManager test tamamlandı.")
