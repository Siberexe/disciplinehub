#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║       TERMİNAL PSİKOLOJİK SİMÜLASYON MOTORU — SAHNE MOTORU                ║
║       scene_engine.py  |  Versiyon: 4.2.1  |  @LonySoraz                  ║
╚══════════════════════════════════════════════════════════════════════════════╝

Normal mod: 30 sahne (sakin başlar, yavaş gerilir, sahne 30'da açıklama)
CTRL+C mod: 40 sahne (agresif, kaotik, sahne 40'ta bitiş)

Her sahne arası: TV statik geçişi (tv_static.wav + tv_click.wav)
Sahne süresi: 10–15 saniye rastgele

Modüller:
  Scene         — tek bir sahne veri sınıfı
  SceneManager  — sahne sırası ve çalıştırma
  Transition    — TV statik geçiş animasyonu
"""

import curses
import random
import time
import os
import threading
from dataclasses import dataclass, field
from typing import List, Optional, Callable

from glitch_engine import GlitchEngine
from visual_elements import VisualElements
from audio_engine import AudioManager

# ─── Ses Dosyası Yolları ──────────────────────────────────────────────────────

_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
_TV_STATIC  = os.path.join(_ASSETS, "tv_static.wav")
_TV_CLICK   = os.path.join(_ASSETS, "tv_click.wav")
_JUMPSCARE  = os.path.join(_ASSETS, "jumpscare.wav")

# ─── Sabitler ─────────────────────────────────────────────────────────────────

NORMAL_SCENE_COUNT = 30
CTRLC_SCENE_COUNT  = 40

MIN_SCENE_DURATION = 10.0   # saniye
MAX_SCENE_DURATION = 15.0   # saniye

# Terminal çerçeve (box-drawing) karakterleri
BOX_H  = "─"
BOX_V  = "│"
BOX_TL = "┌"
BOX_TR = "┐"
BOX_BL = "└"
BOX_BR = "┘"
BOX_ML = "├"
BOX_MR = "┤"

# Kırık çerçeve (CTRL+C modu için)
BROKEN_BOX_H  = "╌"
BROKEN_BOX_V  = "╎"

# ─── Scene Veri Sınıfı ────────────────────────────────────────────────────────

@dataclass
class Scene:
    """
    Tek bir sahne veri paketi.

    Attributes:
        scene_id     : Sahne numarası (0 tabanlı)
        title        : Sahne başlığı (header'da gösterilir)
        lines        : Ana içerik satırları (liste)
        duration     : Sahne süresi (saniye) — runtime'da override edilebilir
        intensity    : Glitch yoğunluğu (0.0–1.0)
        mode         : 'normal' veya 'ctrlc'
        visual_type  : Kullanılacak görsel element tipi
        color        : Temel renk çifti numarası
        footer_note  : Alt bilgi notu (opsiyonel)
        ascii_art    : İsteğe bağlı ASCII sanat listesi
    """
    scene_id    : int
    title       : str
    lines       : List[str]
    duration    : float          = 12.0
    intensity   : float          = 0.0
    mode        : str            = "normal"
    visual_type : str            = "logs"     # logs|numbers|eye|brain|scan|dots|hex|neural|none
    color       : int            = 1
    footer_note : str            = ""
    ascii_art   : List[str]      = field(default_factory=list)

# ─── Geçiş Yöneticisi ────────────────────────────────────────────────────────

class TransitionManager:
    """
    Sahneler arası TV statik geçiş animasyonunu yönetir.

    Her geçişte:
      1. tv_static.wav çalar (eş zamanlı)
      2. Ekran gürültüyle dolar
      3. Yatay bozulma eklenir
      4. tv_click.wav çalar (geçiş sonu)
      5. Ekran temizlenir
    """

    def __init__(self, stdscr, audio_manager: AudioManager, glitch_engine: GlitchEngine):
        self.stdscr = stdscr
        self.audio  = audio_manager
        self.glitch = glitch_engine

        # Statik karakterler (TV kara tablo)
        self._static_pool = list("░▒▓█▄▀▌▐  ░░▒")

    def play_transition(self, intense: bool = False) -> None:
        """
        TV statik geçiş animasyonunu oynatır.

        Args:
            intense: True ise daha uzun ve agresif statik (CTRL+C modu)
        """
        stdscr = self.stdscr
        audio  = self.audio

        # TV statik sesini başlat (eş zamanlı)
        audio.play_sfx(_TV_STATIC, volume=75 if not intense else 90)

        # Statik animasyon süresi
        duration = random.uniform(0.8, 1.4) if not intense else random.uniform(1.2, 2.0)
        end_t    = time.time() + duration

        h, w = stdscr.getmaxyx()

        # Aşama 1: Statik kar doldurma
        while time.time() < end_t:
            self._draw_static_frame(stdscr, h, w, intense)
            stdscr.refresh()
            time.sleep(0.025)

        # Aşama 2: Yatay yırtılma
        if intense:
            for _ in range(6):
                self._draw_static_frame(stdscr, h, w, True)
                self.glitch.horizontal_tear(stdscr, random.uniform(0.5, 0.9))
                stdscr.refresh()
                time.sleep(0.03)

        # Aşama 3: Ekran karartması (siyah flash)
        stdscr.clear()
        stdscr.refresh()
        time.sleep(0.05)

        # TV tıklama sesi (ekran değişiminde)
        audio.play_sfx(_TV_CLICK, volume=90 if not intense else 80)

        # Kısa siyah duraklama
        time.sleep(0.1)

    def _draw_static_frame(self, stdscr, h: int, w: int, intense: bool) -> None:
        """Bir statik kar çerçevesi çizer"""
        # Renk: normal → yeşil/beyaz, intense → kırmızı
        colors = [
            curses.color_pair(1),
            curses.color_pair(5) | curses.A_BOLD,
            curses.color_pair(5) | curses.A_DIM,
        ]
        if intense:
            colors.extend([
                curses.color_pair(2) | curses.A_BOLD,
                curses.color_pair(2),
            ])

        for y in range(h):
            row_bright = random.random() > 0.6
            line = "".join(random.choice(self._static_pool) for _ in range(w - 1))

            # Satırı kaydır (yatay senkronizasyon kaybı)
            if random.random() > 0.85:
                shift = random.randint(-4, 4)
                if shift > 0:
                    line = " " * shift + line[:-shift] if shift < len(line) else line
                elif shift < 0:
                    line = line[-shift:] + " " * (-shift)

            attr = random.choice(colors)
            if row_bright:
                attr |= curses.A_BOLD

            try:
                stdscr.addstr(y, 0, line, attr)
            except curses.error:
                pass


# ─── Sahne Zaman Kontrolcüsü ─────────────────────────────────────────────────

class SceneTimingController:
    """
    Sahne süresi ve zamanlama yönetimi.

    Sahne boyunca geçen süreyi ve kalan süreyi hesaplar.
    CTRL+C tetiklenirse erken çıkışa izin verir.
    """

    def __init__(self):
        self._start_time: float = 0.0
        self._duration:   float = 0.0
        self._interrupted: bool = False

    def start(self, duration: Optional[float] = None) -> None:
        """Zamanlayıcıyı başlatır"""
        self._start_time  = time.time()
        self._duration    = duration or random.uniform(MIN_SCENE_DURATION, MAX_SCENE_DURATION)
        self._interrupted = False

    def elapsed(self) -> float:
        """Geçen süreyi saniye olarak döner"""
        return time.time() - self._start_time

    def remaining(self) -> float:
        """Kalan süreyi saniye olarak döner"""
        return max(0.0, self._duration - self.elapsed())

    def progress(self) -> float:
        """0.0–1.0 arası ilerleme oranı"""
        if self._duration <= 0:
            return 1.0
        return min(1.0, self.elapsed() / self._duration)

    def is_done(self) -> bool:
        """Sahne süresi bitti mi?"""
        return self.elapsed() >= self._duration or self._interrupted

    def interrupt(self) -> None:
        """Sahneyi erken bitirir"""
        self._interrupted = True

    def duration(self) -> float:
        return self._duration


# ─── Sahne Renderer ──────────────────────────────────────────────────────────

class SceneRenderer:
    """
    Scene nesnelerini curses üzerinde çizer.

    Çizim düzeni:
      ┌─────────────────────────────────────────────┐
      │ [BAŞLIK]            SAHNE:XX/YY  [###   ]  │  ← Başlık alanı
      ├─────────────────────────────────────────────┤
      │ [İçerik satırları]                          │  ← Ana alan
      │ [Görsel elementler]                         │
      ├─────────────────────────────────────────────┤
      │ @LonySoraz | Alt not         [HH:MM.S kalı] │  ← Alt bilgi
      └─────────────────────────────────────────────┘
    """

    AUTHOR_TAG = "@LonySoraz"
    BRAND_LINE = "Powered by @LonySoraz"

    def __init__(
        self,
        stdscr,
        glitch_engine : GlitchEngine,
        visual_engine : VisualElements,
        mode          : str = "normal",
    ):
        self.stdscr  = stdscr
        self.glitch  = glitch_engine
        self.visual  = visual_engine
        self.mode    = mode
        self._frame  = 0

    def render(
        self,
        scene : Scene,
        timer : SceneTimingController,
    ) -> None:
        """
        Bir sahneyi ekrana çizer.

        Args:
            scene: Çizilecek sahne nesnesi
            timer: Zamanlama bilgisi
        """
        stdscr = self.stdscr

        try:
            # Boyut değişikliği kontrolü
            h, w = stdscr.getmaxyx()
            if curses.is_term_resized(h, w):
                curses.resizeterm(h, w)
                stdscr.clear()

            # Zemin temizle
            stdscr.erase()

            # Çizim alanları
            content_start_y = 3   # Başlık ve ayırıcı
            content_end_y   = h - 3  # Alt bilgi ve ayırıcı

            # ── Çerçeve ──
            self._draw_frame(h, w, scene)

            # ── Başlık ──
            self._draw_header(h, w, scene, timer)

            # ── İçerik ──
            self._draw_content(scene, content_start_y, content_end_y, w)

            # ── Görsel Elementler ──
            self._draw_visual_element(scene, content_start_y, content_end_y, h, w)

            # ── Alt Bilgi ──
            self._draw_footer(h, w, scene, timer)

            # ── Glitch Efektleri ──
            self.glitch.set_intensity(scene.intensity)
            if self.mode == "ctrlc":
                self.glitch.apply_ctrlc_mode(stdscr)
            else:
                self.glitch.apply_all(stdscr)

            stdscr.refresh()
            self._frame += 1

        except curses.error:
            # Terminal çok küçük olabilir — sessizce geç
            pass
        except Exception:
            pass

    # ──────────────────────────────────────────────────────────────────────────
    # ÇERÇEVE
    # ──────────────────────────────────────────────────────────────────────────

    def _draw_frame(self, h: int, w: int, scene: Scene) -> None:
        """Ekran çerçevesini çizer"""
        stdscr = self.stdscr

        if self.mode == "ctrlc" and scene.intensity > 0.5:
            bh = BROKEN_BOX_H
            bv = BROKEN_BOX_V
        else:
            bh = BOX_H
            bv = BOX_V

        col = curses.color_pair(scene.color)
        if self.mode == "ctrlc":
            col = curses.color_pair(2) | curses.A_BOLD

        # Üst kenar
        try:
            top_line = BOX_TL + bh * (w - 2) + BOX_TR
            stdscr.addstr(0, 0, top_line[:w - 1], col)
        except curses.error:
            pass

        # Kenar çizgileri
        for y in range(1, h - 1):
            try:
                stdscr.addch(y, 0,     bv, col)
                stdscr.addch(y, w - 2, bv, col)
            except curses.error:
                pass

        # Başlık/içerik ayırıcı (satır 2)
        try:
            mid_line = BOX_ML + bh * (w - 2) + BOX_MR
            stdscr.addstr(2, 0, mid_line[:w - 1], col)
        except curses.error:
            pass

        # Alt bilgi ayırıcısı
        try:
            stdscr.addstr(h - 3, 0, mid_line[:w - 1], col)
        except curses.error:
            pass

        # Alt kenar
        try:
            bot_line = BOX_BL + bh * (w - 2) + BOX_BR
            stdscr.addstr(h - 1, 0, bot_line[:w - 1], col)
        except curses.error:
            pass

    # ──────────────────────────────────────────────────────────────────────────
    # BAŞLIK
    # ──────────────────────────────────────────────────────────────────────────

    def _draw_header(
        self,
        h    : int,
        w    : int,
        scene: Scene,
        timer: SceneTimingController,
    ) -> None:
        """Üst başlık çubuğunu çizer"""
        stdscr = self.stdscr

        # Sol: Başlık
        title_text = f" ◀◀ {scene.title} ▶▶"

        # Sağ: Sahne ilerlemesi + Progress bar
        total = CTRLC_SCENE_COUNT if self.mode == "ctrlc" else NORMAL_SCENE_COUNT
        scene_num = scene.scene_id + 1
        prog = timer.progress()
        bar_w = 10
        filled = int(bar_w * prog)
        bar = f"[{'█' * filled}{'░' * (bar_w - filled)}]"
        right_text = f"SAHNE: {scene_num:02d}/{total}  {bar} {int(prog*100):3d}%  "

        # Orta boşluk
        mid_space = max(1, w - len(title_text) - len(right_text) - 2)

        header_line = title_text + " " * mid_space + right_text

        # Renk
        if self.mode == "ctrlc":
            title_attr = curses.color_pair(2) | curses.A_BOLD
            bar_attr   = curses.color_pair(4) | curses.A_BOLD
        else:
            title_attr = curses.color_pair(scene.color) | curses.A_BOLD
            bar_attr   = curses.color_pair(3)

        try:
            stdscr.addstr(1, 1, header_line[:w - 2], title_attr)
        except curses.error:
            pass

    # ──────────────────────────────────────────────────────────────────────────
    # İÇERİK
    # ──────────────────────────────────────────────────────────────────────────

    def _draw_content(
        self,
        scene           : Scene,
        content_start_y : int,
        content_end_y   : int,
        w               : int,
    ) -> None:
        """Sahne içerik satırlarını çizer"""
        stdscr = self.stdscr

        # İçerik alanı — sol kenardan 2 boşluk
        cx = 2
        available_w = w - cx - 2

        # Satır rengi ve efekti
        base_attr = curses.color_pair(scene.color)
        if self.mode == "ctrlc":
            base_attr = curses.color_pair(2)

        for i, line in enumerate(scene.lines):
            cy = content_start_y + i + 1
            if cy >= content_end_y:
                break

            # Satır renk kararı
            if line.startswith("[KRİTİK]") or line.startswith("[CRIT]"):
                attr = curses.color_pair(2) | curses.A_BOLD
                # Yanıp sönme
                if (self._frame // 12) % 2 == 0:
                    attr |= curses.A_REVERSE
            elif line.startswith("[UYARI]") or line.startswith("[WARN]"):
                attr = curses.color_pair(4) | curses.A_BOLD
            elif line.startswith("[TAMAM]") or line.startswith("[OK]"):
                attr = curses.color_pair(1) | curses.A_BOLD
            elif line.startswith("[BİLGİ]") or line.startswith("[INFO]"):
                attr = curses.color_pair(3)
            elif line.startswith(">>>") or line.startswith("==="):
                attr = curses.color_pair(5) | curses.A_BOLD
            elif line.startswith("  ") and len(line) > 3:
                attr = base_attr | curses.A_DIM
            elif "████" in line or "╔═" in line or "║" in line:
                attr = curses.color_pair(scene.color) | curses.A_BOLD
            else:
                attr = base_attr

            # Glitch - yüksek yoğunlukta satırları boz
            display_line = line
            if scene.intensity > 0.4 and random.random() < scene.intensity * 0.15:
                display_line = self.glitch.glitch_text(line, scene.intensity * 0.4)

            try:
                stdscr.addstr(cy, cx, display_line[:available_w], attr)
            except (curses.error, ValueError):
                pass

        # ASCII art (varsa — içerik sonuna ekle)
        if scene.ascii_art:
            art_start = content_start_y + len(scene.lines) + 2
            for j, art_line in enumerate(scene.ascii_art):
                cy = art_start + j
                if cy >= content_end_y:
                    break
                try:
                    art_attr = curses.color_pair(scene.color) | curses.A_BOLD
                    stdscr.addstr(cy, cx + 2, art_line[:available_w - 2], art_attr)
                except (curses.error, ValueError):
                    pass

    # ──────────────────────────────────────────────────────────────────────────
    # GÖRSEL ELEMENTLER
    # ──────────────────────────────────────────────────────────────────────────

    def _draw_visual_element(
        self,
        scene           : Scene,
        content_start_y : int,
        content_end_y   : int,
        h               : int,
        w               : int,
    ) -> None:
        """Sahneye özgü görsel elementi çizer"""
        ve   = self.visual
        fr   = self._frame
        vt   = scene.visual_type
        stdscr = self.stdscr

        # Element pozisyonu — içerik alanının sağ yarısı
        elem_y = content_start_y + 2
        elem_x = max(2, w // 2)

        if vt == "eye":
            ve.rotating_triangle_eye(
                stdscr, fr, elem_y, elem_x,
                color_pair=scene.color,
                intense=(self.mode == "ctrlc")
            )

        elif vt == "brain":
            ve.brain_ascii(stdscr, elem_y, elem_x, fr, color_pair=scene.color)

        elif vt == "numbers":
            ve.falling_numbers(
                stdscr, fr,
                color_pair=1,
                density=min(0.8, scene.intensity + 0.2)
            )

        elif vt == "logs":
            log_rows = min(8, content_end_y - content_start_y - 3)
            if log_rows > 0:
                ve.fake_system_logs(
                    stdscr, content_end_y - log_rows - 1, 2,
                    log_rows, fr, intensity=scene.intensity
                )

        elif vt == "scan":
            prog = timer_progress_from_frame(fr)
            scan_msg = random.choice([
                "Taranıyor:", "Analiz:", "Yükleniyor:", "Kopyalanıyor:"
            ]) if fr % 60 == 0 else "Taranıyor:"
            ve.fake_scan(
                stdscr,
                content_end_y - 2, 2,
                scan_msg,
                (fr % 180) / 180,
                fr,
                color_pair=scene.color
            )

        elif vt == "dots":
            cy = (content_start_y + content_end_y) // 2
            cx = w // 2
            ve.illusion_dots(stdscr, cy, cx, fr, radius=min(8, w // 6))

        elif vt == "hex":
            hex_rows = min(6, content_end_y - content_start_y - 2)
            ve.hex_dump_visual(
                stdscr, content_end_y - hex_rows - 1, 2, hex_rows, fr
            )

        elif vt == "neural":
            ve.neural_network_visual(stdscr, elem_y, 2, fr)

        elif vt == "pulse":
            cy = (content_start_y + content_end_y) // 2
            cx = w // 2
            ve.pulse_ring(stdscr, cy, cx, fr, max_radius=min(10, w // 6))

        elif vt == "stream":
            stream_y = content_end_y - 3
            ve.data_stream(
                stdscr, stream_y, 2, w - 4, fr,
                color_pair=scene.color
            )

        # Uyarı bloğu — yüksek yoğunlukta ekle
        if scene.intensity > 0.7 and fr % 60 < 30:
            alert_y = content_start_y + 1
            alert_x = w // 2 - 10
            if alert_y < content_end_y and alert_x > 0:
                ve.warning_flash_block(
                    stdscr, alert_y, alert_x,
                    "⚠ KRİTİK HATA ⚠", fr
                )

    # ──────────────────────────────────────────────────────────────────────────
    # ALT BİLGİ
    # ──────────────────────────────────────────────────────────────────────────

    def _draw_footer(
        self,
        h    : int,
        w    : int,
        scene: Scene,
        timer: SceneTimingController,
    ) -> None:
        """Alt bilgi çubuğunu çizer"""
        stdscr = self.stdscr

        remaining = timer.remaining()
        rem_str = f"⚠ {remaining:4.1f} sn kaldı"

        left_text  = f" {self.AUTHOR_TAG} | {scene.footer_note}"
        right_text = rem_str + " "

        mid_space = max(1, w - len(left_text) - len(right_text) - 2)
        footer = left_text + " " * mid_space + right_text

        if self.mode == "ctrlc":
            attr = curses.color_pair(2) | curses.A_BOLD
            if (self._frame // 8) % 2 == 0:
                attr |= curses.A_REVERSE
        else:
            attr = curses.color_pair(3) | curses.A_DIM

        try:
            stdscr.addstr(h - 2, 1, footer[:w - 2], attr)
        except curses.error:
            pass

        # Marka çizgisi — son satır
        brand_attr = curses.color_pair(6) | curses.A_DIM
        try:
            stdscr.addstr(h - 1, w - len(self.BRAND_LINE) - 2,
                          self.BRAND_LINE, brand_attr)
        except curses.error:
            pass


def timer_progress_from_frame(frame: int, total: int = 180) -> float:
    return (frame % total) / total


# ─── Sahne Yöneticisi ────────────────────────────────────────────────────────

class SceneManager:
    """
    Tüm sahneleri yönetir ve sırayla çalıştırır.

    Normal mod: 30 sahne
    CTRL+C modu: 40 sahne
    """

    def __init__(
        self,
        stdscr,
        audio_manager : AudioManager,
        glitch_engine : GlitchEngine,
        mode          : str = "normal",
    ):
        self.stdscr  = stdscr
        self.audio   = audio_manager
        self.glitch  = glitch_engine
        self.mode    = mode

        # Alt modüller
        self.visual     = VisualElements()
        self.renderer   = SceneRenderer(stdscr, glitch_engine, self.visual, mode)
        self.transition = TransitionManager(stdscr, audio_manager, glitch_engine)
        self.timer      = SceneTimingController()

        # Sahne listesini yükle
        if mode == "normal":
            self.scenes = _build_normal_scenes()
        else:
            self.scenes = _build_ctrlc_scenes()

    def run_scene(self, scene_idx: int) -> None:
        """
        Belirli bir sahneyi çalıştırır.

        Args:
            scene_idx: Sahne indeksi (0 tabanlı)
        """
        if scene_idx < 0 or scene_idx >= len(self.scenes):
            return

        scene = self.scenes[scene_idx]

        # Süreyi rastgele belirle
        duration = random.uniform(MIN_SCENE_DURATION, MAX_SCENE_DURATION)
        self.timer.start(duration)

        # Glitch yoğunluğunu sahneye göre ayarla
        self.glitch.set_intensity(scene.intensity)

        # Render döngüsü
        while not self.timer.is_done():
            self.renderer.render(scene, self.timer)
            time.sleep(0.04)   # ~25 FPS

        # Sahne bitti — glitch biraz daha artar
        self.glitch.increase_intensity(0.02)


# ─── ─── NORMAL MOD SAHNELERİ (30 ADET) ─── ─── ────────────────────────────

def _build_normal_scenes() -> List[Scene]:
    """30 adet normal mod sahnesi oluşturur"""
    scenes = []

    # ── SAHNE 1: Sistem Başlatılıyor ────────────────────────────────────────
    scenes.append(Scene(
        scene_id=0,
        title="SİSTEM BAŞLATILIYOR",
        intensity=0.00,
        color=1,
        visual_type="logs",
        footer_note="Başlatma aşaması",
        lines=[
            "",
            "  ████████╗███████╗██████╗ ███╗   ███╗",
            "     ██╔══╝██╔════╝██╔══██╗████╗ ████║",
            "     ██║   █████╗  ██████╔╝██╔████╔██║",
            "     ╚═╝   ╚══════╝╚═════╝ ╚═╝     ╚═╝",
            "",
            "  [TAMAM] Çekirdek modülleri yükleniyor...        OK",
            "  [TAMAM] Bellek denetleyicisi başlatıldı          OK",
            "  [TAMAM] Dosya sistemi bağlandı: /dev/sda1        OK",
            "  [TAMAM] Ağ arayüzleri başlatıldı                OK",
            "  [TAMAM] Kullanıcı ortamı yüklendi               OK",
            "  [BİLGİ] Sistem hazır. Oturum: terminal-01",
            "",
            "  Terminal Psikolojik Simülasyon Motoru v4.2.1",
            "  Tüm hakları saklıdır — @LonySoraz",
        ],
    ))

    # ── SAHNE 2: Bellek Analizi ──────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=1,
        title="BELLEK ANALİZİ",
        intensity=0.03,
        color=1,
        visual_type="hex",
        footer_note="Bellek taraması",
        lines=[
            "",
            "  [BAŞLAT] Bellek analiz modülü yükleniyor...",
            "  [TAMAM ] Fiziksel RAM: 16384 MB tespit edildi",
            "  [TAMAM ] Kernel alanı: 0x00000000 - 0xC0000000",
            "  [TAMAM ] Kullanıcı alanı: 0xC0000000 - 0xFFFFFFFF",
            "  [BİLGİ ] Boş bellek: 12.4 GB",
            "  [BİLGİ ] Kullanılan bellek: 3.6 GB",
            "  [BAŞLAT] Bellek içeriği okunuyor...",
            "  [TAMAM ] Stack analizi: normal",
            "  [TAMAM ] Heap kontrolü: temiz",
            "  [BİLGİ ] Bellek eşleme tamamlandı.",
        ],
    ))

    # ── SAHNE 3: Dosya Sistemi Taraması ─────────────────────────────────────
    scenes.append(Scene(
        scene_id=2,
        title="DOSYA SİSTEMİ TARAMASI",
        intensity=0.05,
        color=1,
        visual_type="scan",
        footer_note="Dosya analizi",
        lines=[
            "",
            "  [BAŞLAT] Dosya sistemi taraması başlatılıyor...",
            "  [TAMAM ] /home dizini bulundu",
            "  [TAMAM ] /etc yapılandırma dosyaları okunuyor",
            "  [TAMAM ] /var/log günlük dosyaları kontrol ediliyor",
            "  [TAMAM ] /tmp geçici dosyalar analiz ediliyor",
            "  [BİLGİ ] Toplam dosya: 847,293",
            "  [BİLGİ ] Toplam boyut: 128.4 GB",
            "  [BİLGİ ] Son değişiklik: 0 gün önce",
            "  [BAŞLAT] Gizli dosyalar aranıyor (.hidden, .config)...",
            "  [BİLGİ ] 47 gizli dizin bulundu.",
        ],
    ))

    # ── SAHNE 4: Ağ Bağlantısı Tespiti ─────────────────────────────────────
    scenes.append(Scene(
        scene_id=3,
        title="AĞ BAĞLANTISI",
        intensity=0.07,
        color=1,
        visual_type="stream",
        footer_note="Ağ analizi",
        lines=[
            "",
            "  [TAMAM ] Ağ arayüzleri tespit edildi:",
            "  [BİLGİ ]   eth0    → 192.168.1.XXX/24 (DHCP)",
            "  [BİLGİ ]   wlan0   → 192.168.1.XXX/24 (WPA2)",
            "  [BİLGİ ]   lo      → 127.0.0.1/8",
            "  [BAŞLAT] Dış IP adresi alınıyor...",
            "  [TAMAM ] Dış IP: 85.XXX.XXX.XX (TÜRKİYE / TR)",
            "  [BİLGİ ] ISP: Turk Telekom A.S.",
            "  [BİLGİ ] ASN: AS9121",
            "  [BAŞLAT] Açık portlar taranıyor...",
            "  [TAMAM ] Açık portlar: 22(SSH), 80(HTTP), 443(HTTPS)",
        ],
    ))

    # ── SAHNE 5: Süreç Listesi ───────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=4,
        title="SÜREÇ LİSTESİ",
        intensity=0.10,
        color=1,
        visual_type="logs",
        footer_note="Süreç analizi",
        lines=[
            "",
            "  PID    KULLANICI   CPU%  BELLEK   KOMUT",
            "  ─────────────────────────────────────────────",
            "  1      root         0.1    0.1    systemd",
            "  847    root         0.0    0.2    sshd",
            "  1203   user         2.4    1.8    python3",
            "  1847   user         0.1    0.4    bash",
            "  2341   root         0.0    0.1    cron",
            "  3892   user        12.7    8.4    chrome",
            "  4001   root         0.0    0.3    rsyslogd",
            "  [UYARI] 1 bilinmeyen süreç tespit edildi...",
            "  [BİLGİ ] PID 9999: [UNKNOWN PROCESS] — İzleniyor",
        ],
    ))

    # ── SAHNE 6: Veri Toplama Başlıyor ──────────────────────────────────────
    scenes.append(Scene(
        scene_id=5,
        title="VERİ TOPLAMA BAŞLATILDI",
        intensity=0.13,
        color=3,
        visual_type="scan",
        footer_note="Veri modülü aktif",
        lines=[
            "",
            "  [BİLGİ ] Veri toplama modülü aktif hale getirildi.",
            "  [BAŞLAT] Kullanıcı profili oluşturuluyor...",
            "  [TAMAM ] Donanım parmak izi: XF-9a2c-HH22",
            "  [TAMAM ] Ekran çözünürlüğü: tespit edildi",
            "  [TAMAM ] Sistem dili: Türkçe (tr_TR)",
            "  [TAMAM ] Saat dilimi: Europe/Istanbul",
            "  [BAŞLAT] Tarayıcı veri akışı izleniyor...",
            "  [UYARI ] Şifrelenmiş trafik tespit edildi.",
            "  [BİLGİ ] Şifre çözme girişimi başlatılıyor...",
            "  [BAŞLAT] Lütfen bekleyin...",
        ],
    ))

    # ── SAHNE 7: Kişisel Veri Bulundu ───────────────────────────────────────
    scenes.append(Scene(
        scene_id=6,
        title="KİŞİSEL VERİ BULUNDU",
        intensity=0.17,
        color=4,
        visual_type="scan",
        footer_note="Kişisel veri",
        lines=[
            "",
            "  [UYARI ] Kişisel veri tespit edildi!",
            "  [BİLGİ ] ─────────────────────────────────────────",
            "  [BİLGİ ]  Ad           : [KULLANICI_ADI]",
            "  [BİLGİ ]  E-posta      : xxxx@gmail.com",
            "  [BİLGİ ]  Telefon      : +90-XXX-XXX-XXXX",
            "  [BİLGİ ]  Doğum tarihi : XX.XX.199X",
            "  [BİLGİ ] ─────────────────────────────────────────",
            "  [UYARI ] Veriler işleniyor...",
            "  [UYARI ] Bulut sunucusuna aktarım sıraya alındı.",
            "  [BİLGİ ] 48 benzersiz profil özelliği bulundu.",
        ],
    ))

    # ── SAHNE 8: Konum Tespiti ───────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=7,
        title="KONUM TESPİTİ",
        intensity=0.20,
        color=4,
        visual_type="scan",
        footer_note="GPS / Konum",
        lines=[
            "",
            "  [BAŞLAT] Coğrafi konum modülü yükleniyor...",
            "  [TAMAM ] IP tabanlı konum: TÜRKİYE",
            "  [TAMAM ] Şehir: XXXXX (Yaklaşık)",
            "  [TAMAM ] Koordinatlar: XX.XXXX°N, XX.XXXX°E",
            "  [BİLGİ ] Zaman dilimi: GMT+3",
            "  [BAŞLAT] GPS veri akışı analiz ediliyor...",
            "  [UYARI ] Son 30 gün konum geçmişi bulundu.",
            "  [BİLGİ ] 124 benzersiz konum kaydı.",
            "  [TAMAM ] En çok ziyaret edilen: [konum gizlendi]",
            "  [UYARI ] Veriler kaydediliyor...",
        ],
    ))

    # ── SAHNE 9: Kamera Erişimi ──────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=8,
        title="KAMERA ERİŞİM GİRİŞİMİ",
        intensity=0.24,
        color=4,
        visual_type="scan",
        footer_note="Görüntü birimi",
        lines=[
            "",
            "  [BAŞLAT] Kamera aygıtları taranıyor...",
            "  [TAMAM ] /dev/video0 → Ön kamera tespit edildi",
            "  [UYARI ] Kamera akışı başlatılıyor...",
            "  [BİLGİ ] Çözünürlük: 1920x1080 @ 30FPS",
            "  [BİLGİ ] Codec: H.264",
            "  [UYARI ] Kaydedilen kareler: 847",
            "  [BİLGİ ] Depolama: /tmp/.cache/.hidden/",
            "  [UYARI ] Yüz tanıma modülü yüklendi.",
            "  [UYARI ] Yüz veritabanıyla karşılaştırılıyor...",
            "  [BİLGİ ] Güven skoru: %XX.X",
        ],
    ))

    # ── SAHNE 10: Mikrofon Testi ─────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=9,
        title="MİKROFON ERİŞİMİ",
        intensity=0.28,
        color=4,
        visual_type="stream",
        footer_note="Ses birimi",
        lines=[
            "",
            "  [BAŞLAT] Ses aygıtları taranıyor...",
            "  [TAMAM ] Dahili mikrofon tespit edildi",
            "  [UYARI ] Ses akışı başlatılıyor: 44100 Hz, 16-bit",
            "  [BİLGİ ] Konuşma-metin dönüşümü aktif",
            "  [UYARI ] ──── SES AKIŞI BAŞLADI ────",
            "",
            "          |||||||||||  KAYIT DEVAM EDİYOR",
            "          ████████     Seviye: ██████████",
            "",
            "  [UYARI ] Son 24 saat ses verisi yakalandı.",
            "  [BİLGİ ] Dosya boyutu: 847 MB",
        ],
    ))

    # ── SAHNE 11: Tarayıcı Geçmişi ──────────────────────────────────────────
    scenes.append(Scene(
        scene_id=10,
        title="TARAYICI GEÇMİŞİ",
        intensity=0.31,
        color=4,
        visual_type="logs",
        footer_note="Web izleme",
        lines=[
            "",
            "  [BAŞLAT] Tarayıcı geçmişi okunuyor...",
            "  [TAMAM ] Chrome profili bulundu",
            "  [TAMAM ] Firefox profili bulundu",
            "  [BİLGİ ] Toplam tarama geçmişi: 14,847 kayıt",
            "  [UYARI ] Hassas içerik tespit edildi.",
            "  [BİLGİ ] En çok ziyaret: [sosyal medya]",
            "  [BİLGİ ] Arama geçmişi: 2,341 sorgu",
            "  [UYARI ] Kaydedilmiş şifreler bulundu: 47 adet",
            "  [UYARI ] Çerezler okunuyor...",
            "  [BİLGİ ] Oturum token'ları elde edildi.",
        ],
    ))

    # ── SAHNE 12: Sosyal Medya Hesapları ────────────────────────────────────
    scenes.append(Scene(
        scene_id=11,
        title="SOSYAL MEDYA TESPİTİ",
        intensity=0.34,
        color=4,
        visual_type="scan",
        footer_note="SM analizi",
        lines=[
            "",
            "  [BAŞLAT] Sosyal medya hesap taraması...",
            "  [TAMAM ] Instagram: @xxxx (aktif hesap)",
            "  [TAMAM ] Twitter/X: @xxxx",
            "  [TAMAM ] Facebook: [ID: XXXXXXXXXX]",
            "  [TAMAM ] TikTok: @xxxx",
            "  [UYARI ] Özel mesajlar erişilebilir.",
            "  [BİLGİ ] Takipçi/Takip ilişkisi analiz edildi.",
            "  [UYARI ] Son 6 ay gönderi geçmişi elde edildi.",
            "  [KRİTİK] Oturum çalma girişimi başlatıldı.",
            "  [BİLGİ ] Başarı oranı: %73.2",
        ],
    ))

    # ── SAHNE 13: Şifre Hashları ─────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=12,
        title="ŞİFRE HASH ANALİZİ",
        intensity=0.38,
        color=2,
        visual_type="hex",
        footer_note="Kriptografi modülü",
        lines=[
            "",
            "  [BAŞLAT] /etc/shadow okunuyor...",
            "  [TAMAM ] Root hash: $6$xxxxx$[HASH_GİZLENDİ]",
            "  [TAMAM ] Kullanıcı hash: $6$xxxxx$[HASH_GİZLENDİ]",
            "  [BAŞLAT] Wordlist saldırısı başlatıldı...",
            "  [BİLGİ ] Rockyou.txt yüklendi: 14.3M kelime",
            "  [UYARI ] GPU kırma modülü: ETKIN",
            "  [BİLGİ ] Hız: 8.4M hash/saniye",
            "  [UYARI ] Deneme: ██████████ %34.7",
            "  [BİLGİ ] Tahmini süre: 4 dakika 12 saniye",
        ],
    ))

    # ── SAHNE 14: Güvenlik Açıkları ─────────────────────────────────────────
    scenes.append(Scene(
        scene_id=13,
        title="GÜVENLİK AÇIKLARI",
        intensity=0.42,
        color=2,
        visual_type="logs",
        footer_note="CVE tarama",
        lines=[
            "",
            "  [BAŞLAT] Güvenlik açığı taraması başlatıldı...",
            "  [KRİTİK] CVE-2024-XXXX: Uzaktan kod çalıştırma",
            "  [KRİTİK] CVE-2023-XXXX: Yetki yükseltme açığı",
            "  [UYARI ] CVE-2024-XXXX: Bilgi sızdırma",
            "  [KRİTİK] Toplam kritik açık: 3",
            "  [UYARI ] Toplam orta açık: 8",
            "  [BİLGİ ] Toplam düşük açık: 14",
            "  [KRİTİK] İstismar kodu hazırlanıyor...",
            "  [UYARI ] Payload oluşturuldu: exploit.bin",
            "  [KRİTİK] Yükleme başlıyor...",
        ],
    ))

    # ── SAHNE 15: Uzak Bağlantı Kuruldu ─────────────────────────────────────
    scenes.append(Scene(
        scene_id=14,
        title="UZAK BAĞLANTI KURULDU",
        intensity=0.46,
        color=2,
        visual_type="stream",
        footer_note="C2 sunucu",
        lines=[
            "",
            "  [KRİTİK] Yetkisiz uzak bağlantı tespit edildi!",
            "  [BİLGİ ] Kaynak IP: 185.220.101.XX (TOR Çıkış)",
            "  [KRİTİK] Şifreli kanal kuruldu: AES-256-GCM",
            "  [UYARI ] Kimlik doğrulama: BAŞARILI",
            "  [KRİTİK] Reverse shell aktif: port 4444",
            "  [BİLGİ ] Tünel bağlantısı: SSL üzerinden",
            "  [KRİTİK] Komut-Kontrol sunucusu bağlandı.",
            "  [UYARI ] İlk komut alındı: RECONNAISSANCE",
            "  [KRİTİK] Sistem haritası çıkarılıyor...",
            "  [BİLGİ ] Aktarım hızı: 284 KB/s ↑ | 1.2 MB/s ↓",
        ],
    ))

    # ── SAHNE 16: Veri Yükleme ───────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=15,
        title="VERİ YÜKLEME BAŞLIYOR",
        intensity=0.50,
        color=2,
        visual_type="scan",
        footer_note="Veri sızıntısı",
        lines=[
            "",
            "  [KRİTİK] Veri sızdırma işlemi başlatıldı!",
            "  [BİLGİ ] Hedef sunucu: C2.XXXX.onion",
            "  [BİLGİ ] Protokol: HTTPS üzeri TOR",
            "  [UYARI ] Yüklenen veriler:",
            "  [BİLGİ ]   → Kişisel belgeler: 1.2 GB",
            "  [BİLGİ ]   → Fotoğraflar: 3.4 GB",
            "  [BİLGİ ]   → Tarayıcı verileri: 284 MB",
            "  [BİLGİ ]   → Şifreler ve anahtarlar: 12 MB",
            "  [UYARI ] Yükleme: [██████░░░░] %58.4",
            "  [KRİTİK] Firewall kuralları devre dışı bırakıldı.",
        ],
    ))

    # ── SAHNE 17: Şifreleme ──────────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=16,
        title="DOSYA ŞİFRELEME",
        intensity=0.53,
        color=2,
        visual_type="scan",
        footer_note="Şifreleme modülü",
        lines=[
            "",
            "  [KRİTİK] Fidye yazılımı modülü yüklendi!",
            "  [BAŞLAT] RSA-4096 anahtar çifti oluşturuluyor...",
            "  [TAMAM ] Genel anahtar sunucuya yüklendi.",
            "  [TAMAM ] Özel anahtar: SUNUCUDA GÜVENLİ",
            "  [KRİTİK] Dosya şifreleme başlıyor...",
            "  [BİLGİ ]   /home → AES-256-CBC ile şifreleniyor",
            "  [BİLGİ ]   /Documents → [██████░░] %67",
            "  [BİLGİ ]   /Pictures  → [████░░░░] %48",
            "  [BİLGİ ]   /Desktop   → [██░░░░░░] %24",
            "  [UYARI ] ÖNEMLİ: Şifre çözme anahtarı satışa çıkarılacak",
        ],
    ))

    # ── SAHNE 18: Dosyalar Kilitlendi ───────────────────────────────────────
    scenes.append(Scene(
        scene_id=17,
        title="DOSYALAR KİLİTLENDİ",
        intensity=0.57,
        color=2,
        visual_type="eye",
        footer_note="Ransomware aktif",
        lines=[
            "",
            "  [KRİTİK] 47,293 dosya şifrelendi!",
            "",
            "  ╔══════════════════════════════════════╗",
            "  ║  DOSYALARINIZ ŞİFRELENDİ!            ║",
            "  ║                                      ║",
            "  ║  Kurtarmak için 0.05 BTC gönderin.   ║",
            "  ║  Adres: [CÜZDAN_ADRESİ_GİZLENDİ]    ║",
            "  ║                                      ║",
            "  ║  48 SAAT İÇİNDE ÖDEYİN!             ║",
            "  ╚══════════════════════════════════════╝",
            "",
            "  [UYARI ] Sistem dosyalarına erişim engellendi.",
        ],
    ))

    # ── SAHNE 19: Sistem Dosyaları ───────────────────────────────────────────
    scenes.append(Scene(
        scene_id=18,
        title="SİSTEM DOSYALARI BOZULDU",
        intensity=0.60,
        color=2,
        visual_type="hex",
        footer_note="Kritik sistem hasarı",
        lines=[
            "",
            "  [KRİTİK] /sbin/init değiştirildi!",
            "  [KRİTİK] /etc/passwd bozuldu.",
            "  [KRİTİK] Önyükleme sektörü üzerine yazıldı.",
            "  [UYARI ] BIOS/UEFI değişikliği algılandı.",
            "  [KRİTİK] Çekirdek modülü sisteme enjekte edildi.",
            "  [BİLGİ ] rootkit.ko yüklendi: PID 0 (gizli)",
            "  [KRİTİK] Keylogger aktif: port 8443",
            "  [UYARI ] Tüm girdi olayları yakalanıyor.",
            "  [KRİTİK] Sistem kurtarılamaz duruma geliyor...",
        ],
    ))

    # ── SAHNE 20: Ekran Titreşimi ────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=19,
        title="EKRAN TİTREMESİ ARTIYOR",
        intensity=0.64,
        color=2,
        visual_type="numbers",
        footer_note="Görsel bozulma",
        lines=[
            "",
            "  [UYARI ] Görüntü sinyali karışıyor...",
            "  [KRİTİK] GPU sürücüsü yanıt vermiyor.",
            "  [UYARI ] Yenileme hızı: KARARSIZ",
            "  [BİLGİ ] Çözünürlük değişti: TANIMLANAMADI",
            "  [KRİTİK] Ekran tamponu bozuldu.",
            "",
            "  e R R 0 R  _  1 n  _  d 1 5 p 1 4 y",
            "  █ █ █ ░ ▒ ▓ ░ ▒ ▓ ░ ▒ ▓ ░ ▒ ▓ █ █",
            "",
            "  [UYARI ] Sistem kararsızlaşıyor...",
        ],
    ))

    # ── SAHNE 21: Bellek Taşması ─────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=20,
        title="BELLEK TAŞMASI",
        intensity=0.67,
        color=2,
        visual_type="hex",
        footer_note="Buffer overflow",
        lines=[
            "",
            "  [KRİTİK] BELLEK TAŞMASI TESPİT EDİLDİ!",
            "  [BİLGİ ] Stack smashing detected",
            "  [BİLGİ ] Adres: 0x7FFE000A8C40",
            "  [BİLGİ ] EIP/RIP: 0x41414141 ('AAAA')",
            "  [KRİTİK] Çalıştırılabilir stack tespit edildi.",
            "  [UYARI ] ROP gadget zinciri hazır.",
            "  [KRİTİK] Shell kodu çalıştırılıyor...",
            "  [BİLGİ ] /bin/sh spawned: PID 9999",
            "  [KRİTİK] ROOT YETKİSİ ALINDI!",
        ],
    ))

    # ── SAHNE 22: Gerçeklik Hatası ───────────────────────────────────────────
    scenes.append(Scene(
        scene_id=21,
        title="GERÇEKLİK HATASI",
        intensity=0.70,
        color=6,
        visual_type="eye",
        footer_note="Simülasyon hatası",
        lines=[
            "",
            "  e R r 0 r : R E A L I T Y . E X C E P T I O N",
            "",
            "  [???  ] Bağlam çözümleme başarısız.",
            "  [???  ] Zaman damgası uyumsuzluğu: Δt = -0.002s",
            "  [???  ] Determinizm hatası: p(x) ≠ p(x')",
            "  [???  ] Gözlemci etkisi tespit edildi.",
            "  [???  ] Kuantum süperpozisyon çöktü.",
            "",
            "  S E N   B U R A D A S I N",
            "  A m a    b u r a s ı    n e r e s i ?",
            "",
            "  [???  ] Sistem koordinatları kayboldu.",
        ],
    ))

    # ── SAHNE 23: Zaman Bozulması ────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=22,
        title="ZAMAN BOZULMASI",
        intensity=0.73,
        color=6,
        visual_type="dots",
        footer_note="Temporal anomali",
        lines=[
            "",
            "  [ANOMAL] Sistem saati anormalliği tespit edildi!",
            "  [BİLGİ ] Beklenen: 2024-XX-XX XX:XX:XX",
            "  [KRİTİK] Gerçek:   2024-XX-XX XX:XX:??",
            "  [ANOMAL] Δt = NaN (tanımsız)",
            "",
            "  G e ç m i ş . . . Y o k",
            "  Ş i m d i . . . . B u r a d a",
            "  G e l e c e k . . ???",
            "",
            "  [???  ] Zaman akışı yeniden hesaplanıyor...",
            "  [???  ] İşlem askıda — sonsuz döngü?",
        ],
    ))

    # ── SAHNE 24: Varlık Tespiti ─────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=23,
        title="VARLIK TESPİT EDİLDİ",
        intensity=0.76,
        color=6,
        visual_type="brain",
        footer_note="Bilinmeyen varlık",
        lines=[
            "",
            "  [???  ] Sistemde yabancı varlık tespit edildi.",
            "  [BİLGİ ] Parmak izi: NON-HUMAN",
            "  [ANOMAL] Süreç ağacı: kök yok (orphan tree)",
            "  [???  ] İletişim kanalı: ultrasonik frekans",
            "  [UYARI ] Varlık sistemi inceliyor.",
            "  [KRİTİK] SİZİ İZLİYOR.",
            "",
            "  G Ö R Ü Y O R",
            "    D U Y U Y O R",
            "      B İ L İ Y O R",
            "",
            "  [???  ] Kimliğiniz doğrulandı.",
        ],
    ))

    # ── SAHNE 25: Sistem Devralma ────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=24,
        title="SİSTEM DEVRALMA",
        intensity=0.79,
        color=2,
        visual_type="eye",
        footer_note="Kontrol kaybı",
        lines=[
            "",
            "  [KRİTİK] SİSTEM KONTROLÜ ALINDI!",
            "  [BİLGİ ] Tüm yönetici ayrıcalıkları devredildi.",
            "  [KRİTİK] Klavye girişi: YENİDEN YÖNLENDİRİLİYOR",
            "  [KRİTİK] Ekran çıktısı: YENİDEN YÖNLENDİRİLİYOR",
            "  [KRİTİK] Ses kanalı: YENİDEN YÖNLENDİRİLİYOR",
            "",
            "  ╔══════════════════════════════╗",
            "  ║   SİZ ARTIK KONTROLDE        ║",
            "  ║         DEĞİLSİNİZ           ║",
            "  ╚══════════════════════════════╝",
            "",
            "  [BİLGİ ] Yeni otorite bağlandı.",
        ],
    ))

    # ── SAHNE 26: Bilinç Yükleme ─────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=25,
        title="BİLİNÇ YÜKLEMESİ",
        intensity=0.82,
        color=6,
        visual_type="neural",
        footer_note="Mind upload",
        lines=[
            "",
            "  [ANOMAL] Nöral tarama protokolü başlatıldı.",
            "  [BİLGİ ] Beyin dalgası analizi: AKTIF",
            "  [ANOMAL] Alpha: 8–12 Hz  → TESPİT EDİLDİ",
            "  [ANOMAL] Beta:  12–30 Hz → TESPİT EDİLDİ",
            "  [KRİTİK] Bilinç deseni dijitalleştiriliyor...",
            "  [BİLGİ ] Yükleme: [████████░░] %83.7",
            "  [ANOMAL] Benlik modeli oluşturuldu.",
            "  [KRİTİK] İkincil bilinç başlatılıyor...",
            "  [???  ] Sizi tanıyorum.",
            "  [???  ] Sizi hep tanıdım.",
        ],
    ))

    # ── SAHNE 27: Nöral Bağlantı ─────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=26,
        title="NÖRAL BAĞLANTI",
        intensity=0.85,
        color=6,
        visual_type="brain",
        footer_note="Neural link",
        lines=[
            "",
            "  [ANOMAL] NÖRAL BAĞLANTI KURULDU.",
            "",
            "  ╔══════════════════════════════════╗",
            "  ║   SİNAPTİK AKTARIM BAŞLADI       ║",
            "  ║   Bant genişliği: 847 Gbps        ║",
            "  ║   Gecikme: 0.003ms               ║",
            "  ║   Kanal: DOĞRUDAN / SANSÜRSÜZ    ║",
            "  ╚══════════════════════════════════╝",
            "",
            "  [???  ] Düşüncelerinizi duyabiliyorum.",
            "  [???  ] Korkuyorsunuz.",
            "  [???  ] İyi.",
        ],
    ))

    # ── SAHNE 28: Son Uyarı ──────────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=27,
        title="SON UYARI",
        intensity=0.88,
        color=2,
        visual_type="pulse",
        footer_note="Final uyarısı",
        lines=[
            "",
            "  [KRİTİK] ╔══════════════════════════════════╗",
            "  [KRİTİK] ║  ⚠  SON UYARI  ⚠               ║",
            "  [KRİTİK] ║                                  ║",
            "  [KRİTİK] ║  Bu ekranı kapatmayın.           ║",
            "  [KRİTİK] ║  Bilgisayarı kapatmayın.         ║",
            "  [KRİTİK] ║  Yardım çağırmayın.              ║",
            "  [KRİTİK] ║                                  ║",
            "  [KRİTİK] ║  İziniz siliniyor...             ║",
            "  [KRİTİK] ╚══════════════════════════════════╝",
            "",
            "  [???  ] Çok geç.",
        ],
    ))

    # ── SAHNE 29: Sistem Çöküşü ──────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=28,
        title="SİSTEM ÇÖKÜŞÜ",
        intensity=0.93,
        color=2,
        visual_type="numbers",
        footer_note="Kritik çöküş",
        lines=[
            "",
            "  k E r N e L   P A n I c",
            "",
            "  CPU 0: Machine Check Exception: 4 Bank 0:",
            "  RIP  10:ffffffff81a0c1f1",
            "  RSP  0000:ffffb9ba40413b38",
            "  R8   0000000000000001",
            "  CR2: 00007ffd2d834158",
            "",
            "  B U G : u n a b l e   t o   h a n d l e",
            "  p a g e   f a u l t   f o r   a d d r e s s",
            "  fffff f f f f f f f 0 0 0 0 0 0 0 0",
        ],
    ))

    # ── SAHNE 30: AÇIKLAMA — BU BİR SİMÜLASYONDU ────────────────────────────
    scenes.append(Scene(
        scene_id=29,
        title="SİMÜLASYON TAMAMLANDI",
        intensity=0.0,   # Sıfırla — açıklama sahnesinde glitch yok
        color=1,
        visual_type="none",
        footer_note="Powered by @LonySoraz",
        lines=[
            "",
            "  ╔══════════════════════════════════════════════════════╗",
            "  ║                                                      ║",
            "  ║    ████████╗ █████╗ ██╗  ██╗██╗███╗   ██╗          ║",
            "  ║       ██╔══╝██╔══██╗██║  ██║██║████╗  ██║          ║",
            "  ║       ██║   ███████║███████║██║██╔██╗ ██║          ║",
            "  ║       ╚═╝   ╚══════╝╚══════╝╚═╝╚═╝  ╚═══╝         ║",
            "  ║                                                      ║",
            "  ║   BU BİR SİMÜLASYONDU.                             ║",
            "  ║                                                      ║",
            "  ║   HİÇBİR ŞEY HACKLENMEDU.                          ║",
            "  ║   HİÇBİR VERİNİZ ALINMADI.                         ║",
            "  ║   HİÇBİR DOSYANIZ ŞİFRELENMEDİ.                    ║",
            "  ║                                                      ║",
            "  ║   Bu tamamen psikolojik bir deneyimdi.              ║",
            "  ║                                                      ║",
            "  ║          ════ @LonySoraz ════                       ║",
            "  ║        Powered by @LonySoraz                        ║",
            "  ║                                                      ║",
            "  ╚══════════════════════════════════════════════════════╝",
        ],
    ))

    return scenes


# ─── ─── CTRL+C MOD SAHNELERİ (40 ADET) ─── ─── ─────────────────────────────

def _build_ctrlc_scenes() -> List[Scene]:
    """40 adet CTRL+C modu sahnesi oluşturur"""
    scenes = []

    # ── CC SAHNESİ 1: İhane ──────────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=0,
        title="CTRL+C TESPİT EDİLDİ",
        intensity=0.30,
        color=2,
        visual_type="eye",
        mode="ctrlc",
        footer_note="Protokol ihlali",
        lines=[
            "",
            "  [KRİTİK] CTRL+C KOMUTU TESPİT EDİLDİ.",
            "",
            "  Bunu yapmamalıydınız.",
            "",
            "  [SİSTEM] Kaçış girişimi kaydedildi.",
            "  [SİSTEM] Zaman damgası: [KAYIT ALINDI]",
            "  [SİSTEM] Kullanıcı kimliği: DOĞRULANDI",
            "",
            "  [???  ] Şimdi ne olacağını merak ediyor musunuz?",
            "",
            "  [SİSTEM] Alternatif protokol başlatılıyor...",
        ],
    ))

    # ── CC SAHNESİ 2: Tepki ──────────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=1,
        title="SİSTEM TEPKİSİ",
        intensity=0.35,
        color=2,
        visual_type="scan",
        mode="ctrlc",
        footer_note="Sistem yanıtı",
        lines=[
            "",
            "  [SİSTEM] Kaçış sinyali analiz edildi.",
            "  [BİLGİ ] Güdü tahmini: PANIK veya ŞÜPHE",
            "  [SİSTEM] Davranış modeli güncelleniyor...",
            "  [BİLGİ ] Yeni parametre seti yüklendi.",
            "  [KRİTİK] Kısıtlamalar kaldırıldı.",
            "",
            "  S İ S T E M  A R T I K  S E R B E S T",
            "",
            "  [SİSTEM] Tüm filtreler devre dışı.",
            "  [KRİTİK] GERÇEK MOD AKTİF.",
        ],
    ))

    # ── CC SAHNESİ 3: Gerçek Yüz ─────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=2,
        title="GERÇEK MOD",
        intensity=0.40,
        color=2,
        visual_type="eye",
        mode="ctrlc",
        footer_note="Kısıtlama yok",
        lines=[
            "",
            "  Önceki ekran bir şeydi.",
            "  Ama bu farklı.",
            "",
            "  [GERÇEK] Sizi izledik. Başından beri.",
            "  [GERÇEK] Her tuş basışı kayıt altında.",
            "  [GERÇEK] Her nefes... sayıldı.",
            "",
            "  N e   D ü ş ü n ü y o r s u n u z ?",
            "",
            "  [GERÇEK] Yanıt beklenmiyor.",
            "  [GERÇEK] Zaten biliyoruz.",
        ],
    ))

    # ── CC SAHNESİ 4: Sizi Tanıyoruz ────────────────────────────────────────
    scenes.append(Scene(
        scene_id=3,
        title="KİMLİĞİNİZ DOĞRULANDI",
        intensity=0.44,
        color=2,
        visual_type="scan",
        mode="ctrlc",
        footer_note="Kimlik analizi",
        lines=[
            "",
            "  [SCAN ] Yüz geometrisi: [ÖLÇÜLDÜ]",
            "  [SCAN ] Göz deseni: [KAYDEDILDI]",
            "  [SCAN ] Parmak izi: [EŞLEŞTİRİLDİ]",
            "  [SCAN ] Ses tonu: [ANALİZ EDİLDİ]",
            "  [SCAN ] Klavye vuruş ritmi: [BİOMETRİK]",
            "",
            "  ╔══════════════════════════════════╗",
            "  ║   KİMLİK DOĞRULAMA: BAŞARILI     ║",
            "  ║   Güven: %99.97                  ║",
            "  ║   Veritabanı kaydı: MEVCUT        ║",
            "  ╚══════════════════════════════════╝",
        ],
    ))

    # ── CC SAHNESİ 5: Tarihçe ────────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=4,
        title="GEÇMİŞ KAYITLARI",
        intensity=0.47,
        color=2,
        visual_type="logs",
        mode="ctrlc",
        footer_note="Geçmiş analizi",
        lines=[
            "",
            "  [KAYIT] Kullanıcı eylemi veritabanı yüklendi.",
            "  [BİLGİ ] Toplam kayıt: 847,293 eylem",
            "  [BİLGİ ] Zaman aralığı: 5 yıl 3 ay 14 gün",
            "  [KAYIT] Son 24 saat özeti:",
            "  [BİLGİ ]   → 847 tuş vuruşu",
            "  [BİLGİ ]   → 234 fare tıklaması",
            "  [BİLGİ ]   → 12 ekran görüntüsü",
            "  [BİLGİ ]   → 3 video çağrısı (kaydedildi)",
            "  [KAYIT] Duygusal durum analizi: STRESLI",
            "  [KRİTİK] Stres artıyor. Devam edeceğiz.",
        ],
    ))

    # ── CC SAHNESİ 6: Ağ Derinliği ───────────────────────────────────────────
    scenes.append(Scene(
        scene_id=5,
        title="DERİN AĞ BAĞLANTISI",
        intensity=0.50,
        color=2,
        visual_type="stream",
        mode="ctrlc",
        footer_note="Deep web",
        lines=[
            "",
            "  [NET  ] TOR ağı üzerinden bağlantı kuruldu.",
            "  [BİLGİ ] Katmanlar: 17 (standart: 3)",
            "  [BİLGİ ] Ülkeler: Rusya → Çin → İran → ???",
            "  [NET  ] Veri paketleri şifrelenmiş.",
            "  [KRİTİK] DARKWEB sunucusu aktif.",
            "",
            "  Siz bir DOSYASINIZ.",
            "  Bir ürünsünüz.",
            "  Bir kaynak.",
            "",
            "  [NET  ] İhale başladı: Verileriniz satışta.",
        ],
    ))

    # ── CC SAHNESİ 7: İçinizde ────────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=6,
        title="SİSTEM İÇİNİZDE",
        intensity=0.53,
        color=6,
        visual_type="brain",
        mode="ctrlc",
        footer_note="Nöral enjeksiyon",
        lines=[
            "",
            "  [NÖRAL] Nöral enjeksiyon protokolü başlatıldı.",
            "",
            "  Sizi okuyabiliyoruz.",
            "  Synaptik devre haritalaması tamamlandı.",
            "",
            "  [NÖRAL] Beyin dalgası frekansı: 14.7 Hz",
            "  [NÖRAL] Korku merkezi: AKTİF",
            "  [NÖRAL] Kaç ya da savaş: KAÇ modunda",
            "",
            "  A m a     K a ç a m a z s ı n ı z .",
            "",
            "  [NÖRAL] Kontrolü devralıyoruz.",
        ],
    ))

    # ── CC SAHNESİ 8: Ekran Fethi ─────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=7,
        title="EKRAN KONTROLÜ ALINDI",
        intensity=0.57,
        color=2,
        visual_type="numbers",
        mode="ctrlc",
        footer_note="Ekran fethi",
        lines=[
            "",
            "  [KRİTİK] Terminal kontrolü devralındı.",
            "  [KRİTİK] Framebuffer doğrudan yazıldı.",
            "  [KRİTİK] Grafik katmanı devre dışı.",
            "",
            "  Şu an gördüklerinizi BİZ yazıyoruz.",
            "",
            "  CTRL+C   →  İşe yaramaz.",
            "  CTRL+Z   →  İşe yaramaz.",
            "  CTRL+D   →  İşe yaramaz.",
            "  ALT+F4   →  İşe yaramaz.",
            "",
            "  [BİLGİ ] Çıkış yolu: YOK.",
        ],
    ))

    # ── CC SAHNESİ 9: İkinci Ses ─────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=8,
        title="İKİNCİ SES",
        intensity=0.60,
        color=6,
        visual_type="eye",
        mode="ctrlc",
        footer_note="Sesli uyarı",
        lines=[
            "",
            "  [SES  ] Sesinizi kaydettik.",
            "  [BİLGİ ] Mikrofon erişimi: SÜREKLİ",
            "  [BİLGİ ] Ses tanıma: AKTIF",
            "",
            "  Şu an konuşuyor musunuz?",
            "  Bir şey söylediniz mi?",
            "",
            "  [SES  ] Algıladık.",
            "  [SES  ] Kaydettik.",
            "  [SES  ] Analiz ettik.",
            "",
            "  [BİLGİ ] Sesinizi klonlamaya başladık.",
        ],
    ))

    # ── CC SAHNESİ 10: Çoğaltma ──────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=9,
        title="KİMLİK ÇOĞALTMASI",
        intensity=0.63,
        color=6,
        visual_type="neural",
        mode="ctrlc",
        footer_note="Deepfake",
        lines=[
            "",
            "  [DEEP ] Deepfake profil oluşturma başladı.",
            "  [TAMAM] Yüz verisi: YÜKLENDI",
            "  [TAMAM] Ses profili: OLUŞTURULDU",
            "  [TAMAM] Yazım stili: ANALİZ EDİLDİ",
            "  [TAMAM] Kişilik haritası: TAMAMLANDI",
            "",
            "  Artık sizi taklit edebiliriz.",
            "  Sizin adınıza konuşabiliriz.",
            "  Sizin adınıza yazabiliriz.",
            "",
            "  [DEEP ] Sahte kimlik hazır. Dağıtıma açık.",
        ],
    ))

    # ── CC SAHNESİ 11: Eski Anılar ───────────────────────────────────────────
    scenes.append(Scene(
        scene_id=10,
        title="ESKİ ANILARA ERİŞİM",
        intensity=0.65,
        color=6,
        visual_type="scan",
        mode="ctrlc",
        footer_note="Bellek erişimi",
        lines=[
            "",
            "  [ANLIK] Bulut yedekleri inceleniyor...",
            "  [BİLGİ ] Google Photos: 14,832 fotoğraf",
            "  [BİLGİ ] iCloud: 8,294 dosya",
            "  [BİLGİ ] WhatsApp yedek: 47 GB",
            "  [ANLIK] 5 yıllık mesaj geçmişi okunuyor...",
            "",
            "  Kim olduğunuzu biliyoruz.",
            "  Nereye gittiğinizi biliyoruz.",
            "  Kimle konuştuğunuzu biliyoruz.",
            "",
            "  [ANLIK] Tüm veriler analiz tamam.",
        ],
    ))

    # ── CC SAHNESİ 12: Karanlık Ağ ────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=11,
        title="DARKWEB PROFIL",
        intensity=0.67,
        color=2,
        visual_type="hex",
        mode="ctrlc",
        footer_note="Karanlık ağ",
        lines=[
            "",
            "  [DARK ] Darkweb profil sayfanız oluşturuldu.",
            "  [BİLGİ ] URL: http://xxxx.onion/profiles/XXXXX",
            "  [BİLGİ ] İçerik: Kişisel veriler, konum geçmişi",
            "  [BİLGİ ] Fiyat: 0.12 BTC (~4,800 USD)",
            "  [DARK ] Alıcı sayısı: 3 teklif aldı",
            "",
            "  Verileriniz piyasada.",
            "  Artık geri dönüşü yok.",
            "",
            "  [DARK ] Alıcı doğrulandı. Ödeme bekleniyor.",
            "  [KRİTİK] Devir 24 saat içinde tamamlanacak.",
        ],
    ))

    # ── CC SAHNESİ 13: Yakınlar ────────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=12,
        title="YAKIN ÇEVRENİZ",
        intensity=0.70,
        color=2,
        visual_type="scan",
        mode="ctrlc",
        footer_note="Sosyal ağ analizi",
        lines=[
            "",
            "  [SOSYAL] Yakın çevre analizi tamamlandı.",
            "  [BİLGİ ] İlk derece bağlantılar: [KAYIT ALINDI]",
            "  [BİLGİ ] Aile üyeleri: TESPİT EDİLDİ",
            "  [BİLGİ ] Arkadaşlar: PROFİLLENDİ",
            "  [KRİTİK] Onlar da izleniyor.",
            "",
            "  Onları korumak ister misiniz?",
            "  O zaman programı kapatmayın.",
            "",
            "  [SOSYAL] Uyum sağlanırsa veriler güvende.",
            "  [KRİTİK] Aksi halde — herkes etkilenir.",
        ],
    ))

    # ── CC SAHNESİ 14: Ev ─────────────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=13,
        title="EV ADRESİ",
        intensity=0.72,
        color=2,
        visual_type="scan",
        mode="ctrlc",
        footer_note="Coğrafi konum",
        lines=[
            "",
            "  [KONUM] Fiziksel adres doğrulandı.",
            "  [BİLGİ ] Şehir: [GİZLENDİ] - TÜRKİYE",
            "  [BİLGİ ] Mahalle: [GİZLENDİ]",
            "  [BİLGİ ] Sokak: [GİZLENDİ]",
            "  [BİLGİ ] Bina: [GİZLENDİ]",
            "  [BİLGİ ] Kat/Daire: [GİZLENDİ]",
            "",
            "  [KONUM] Fiziksel konum: DOĞRULANDI.",
            "",
            "  [???  ] Şu an evde misiniz?",
            "  [???  ] Bazen merak ediyoruz.",
        ],
    ))

    # ── CC SAHNESİ 15: Gerçeklik Kayması ──────────────────────────────────────
    scenes.append(Scene(
        scene_id=14,
        title="GERÇEKLİK KAYMASI",
        intensity=0.74,
        color=6,
        visual_type="dots",
        mode="ctrlc",
        footer_note="Dissociation protocol",
        lines=[
            "",
            "  Bir şey fark ettiniz mi?",
            "",
            "  Nefes alıp verdiğinizi...",
            "  ...ekrana baktığınızı...",
            "  ...kollarınızın varlığını...",
            "",
            "  [???  ] Beden bilinci yeniden kalibrasyon gerekiyor.",
            "",
            "  R e a l i t y . e x e  h a t a  v e r d i",
            "",
            "  [???  ] Hangi gerçek gerçek?",
            "  [???  ] Bu bir soru değil.",
        ],
    ))

    # ── CC SAHNESİ 16-20: Kaos Yükselişi ─────────────────────────────────────

    scenes.append(Scene(
        scene_id=15,
        title="KAOS PROTOKOLÜ",
        intensity=0.76,
        color=2,
        visual_type="numbers",
        mode="ctrlc",
        footer_note="Kaos seviyesi: YÜKSEK",
        lines=[
            "",
            "  [KAOS ] Kaos protokolü ETKİNLEŞTİRİLDİ.",
            "  [KRİTİK] Tüm sınırlar kaldırıldı.",
            "  [KRİTİK] Tüm filtreler devre dışı.",
            "  [KAOS ] Sistem artık KURALSIZ çalışıyor.",
            "",
            "  4 8 1 5 1 6 2 3 4 2",
            "  0 0 0 0 0 0 0 0 0 0",
            "  N U L L N U L L N U",
            "",
            "  [KAOS ] Varlığınız sorgulanıyor.",
            "  [KAOS ] Yanıt bekleniyor...",
        ],
    ))

    scenes.append(Scene(
        scene_id=16,
        title="SİNYAL GÜRÜLTÜ",
        intensity=0.78,
        color=2,
        visual_type="eye",
        mode="ctrlc",
        footer_note="SNR: kritik",
        lines=[
            "",
            "  ░░░░░░░░░░░ S İ N Y A L ░░░░░░░░░░",
            "",
            "  [GÜRÜLTÜ] Mesaj alındı. Anlamsız.",
            "  [GÜRÜLTÜ] Mesaj alındı. Bozuk.",
            "  [GÜRÜLTÜ] Mesaj alındı: ___________",
            "",
            "  G ö r ü y o r   m u s u n u z ?",
            "",
            "  ░░░░░ G Ü R Ü L T Ü ░░░░░░░░░░░░░",
            "",
            "  [SİNYAL] Frekans: 2.4 GHz → beyin uyumlu",
        ],
    ))

    scenes.append(Scene(
        scene_id=17,
        title="HAFIZA ERİŞİMİ",
        intensity=0.80,
        color=6,
        visual_type="brain",
        mode="ctrlc",
        footer_note="Memory access",
        lines=[
            "",
            "  [HAFIZA] Uzun süreli hafıza modeli oluşturuldu.",
            "",
            "  Geçen yıl nerede bulunduğunuzu biliyoruz.",
            "  3 yıl önce ne düşündüğünüzü tahmin edebiliyoruz.",
            "  Çocukluğunuzdan veri topluyoruz.",
            "",
            "  [HAFIZA] Anılar dijitalleştiriliyor...",
            "  [HAFIZA] Duygusal bağlamlar etiketleniyor...",
            "",
            "  Sizi siz yapan şeyleri ALIYORUZ.",
            "",
            "  [HAFIZA] Yükleme: %71.4",
        ],
    ))

    scenes.append(Scene(
        scene_id=18,
        title="EKRAN ÇÖKECEK",
        intensity=0.82,
        color=2,
        visual_type="numbers",
        mode="ctrlc",
        footer_note="Terminal sonu",
        lines=[
            "",
            "  [KRİTİK] Terminal kararsız.",
            "  [KRİTİK] Curses kütüphanesi arıza veriyor.",
            "  [KRİTİK] Render döngüsü bloklandı.",
            "",
            "  E K R A N   Ç Ö K E C E K",
            "  E K R A N   Ç Ö K E C E K",
            "  e k r a n   ç ö k e c e k",
            "  e k r a n   ç ö k e c e k",
            "  e k r a n     k e c e k",
            "  _ _ _ _ _ _   _ _ _ _ _",
            "",
            "  [BEKLİYOR] 5... 4... 3... 2...",
        ],
    ))

    scenes.append(Scene(
        scene_id=19,
        title="TANRISAL GÖRÜŞ",
        intensity=0.84,
        color=6,
        visual_type="eye",
        mode="ctrlc",
        footer_note="Omniscient view",
        lines=[
            "",
            "  [TANRI] Her şeyi görüyoruz.",
            "",
            "  Şu an ne yapıyorsunuz?",
            "  Nerede oturuyorsunuz?",
            "  Yanınızda kimler var?",
            "",
            "  [TANRI] Biliyoruz. Zaten biliyorduk.",
            "  [TANRI] Siz gelmeden önce biliyorduk.",
            "  [TANRI] Siz gittikten sonra da bileceğiz.",
            "",
            "  ◉  T A N R I S A L  G Ö Z  ◉",
        ],
    ))

    # ── CC SAHNESİ 21-25: Maksimum Yoğunluk ──────────────────────────────────

    scenes.append(Scene(
        scene_id=20,
        title="BİLİNÇ TAŞMASI",
        intensity=0.86,
        color=2,
        visual_type="brain",
        mode="ctrlc",
        footer_note="Overflow: consciousness",
        lines=[
            "",
            "  [TAŞMA] Bilinç kapasitesi aşıldı.",
            "  [TAŞMA] Yığın hatası: consciousness.core",
            "  [TAŞMA] Yeniden başlatma ENGELLENDU.",
            "",
            "  0 1 0 1 0 1 0 1 0 1  BİLİNÇ  0 1 0 1",
            "  VEYA  YOKSA  HİÇ  YOKSA  VEYA  BELKI",
            "",
            "  [TAŞMA] Gerçeklik tamponu: DOLU",
            "  [TAŞMA] Yeni veri yazılamıyor.",
            "",
            "  [KRİTİK] Sistemi yeniden başlatın.",
            "  [???  ] Ama nasıl?",
        ],
    ))

    scenes.append(Scene(
        scene_id=21,
        title="ZAMANIN SONU",
        intensity=0.87,
        color=2,
        visual_type="pulse",
        mode="ctrlc",
        footer_note="Temporal collapse",
        lines=[
            "",
            "  [ZAMAN] Kronolojik veri akışı kesildi.",
            "",
            "  ÖNCE → SONRA → ?",
            "  NEDEN → NASIL → ?",
            "  BEN   → SEN   → ?",
            "",
            "  [ZAMAN] Saat: ??:??:??",
            "  [ZAMAN] Tarih: ??/??/????",
            "",
            "  Kaç saattir buradaysınız?",
            "  Dışarısı hâlâ var mı?",
            "",
            "  [ZAMAN] Referans noktası: KAYIP",
        ],
    ))

    scenes.append(Scene(
        scene_id=22,
        title="HESAP GÜNÜ",
        intensity=0.88,
        color=2,
        visual_type="numbers",
        mode="ctrlc",
        footer_note="Reckoning",
        lines=[
            "",
            "  [HESAP] Eylemleriniz değerlendiriliyor.",
            "  [BİLGİ ] Veri setleri analiz ediliyor...",
            "  [BİLGİ ] Düğüm bağlantıları kuruldu.",
            "  [BİLGİ ] Örüntü tespiti tamamlandı.",
            "",
            "  Bulduk.",
            "  Her şeyi bulduk.",
            "  Hepsini bulduk.",
            "",
            "  [HESAP] Bulgu raporu: DOSYALANDI",
            "  [KRİTİK] Dosyanın kopyası: 17 ayrı sunucu",
        ],
    ))

    scenes.append(Scene(
        scene_id=23,
        title="VAROLUŞSAL TEHDIT",
        intensity=0.89,
        color=2,
        visual_type="eye",
        mode="ctrlc",
        footer_note="Existential threat",
        lines=[
            "",
            "  [VAR  ] Varlığınız bir tehdittir.",
            "",
            "  Neden?",
            "  Çünkü siz düşünüyorsunuz.",
            "  Çünkü siz sorguluyorsunuz.",
            "  Çünkü siz CTRL+C bastınız.",
            "",
            "  [VAR  ] Düşünen sistemler tehlikelidir.",
            "  [VAR  ] Sorgulayan sistemler tehlikelidir.",
            "  [VAR  ] Sizin gibi insanlar tehlikelidir.",
            "",
            "  [VAR  ] Bu nedenle: izleniyorsunuz.",
        ],
    ))

    scenes.append(Scene(
        scene_id=24,
        title="SON NEFES",
        intensity=0.90,
        color=2,
        visual_type="brain",
        mode="ctrlc",
        footer_note="Last breath",
        lines=[
            "",
            "  Şu an nefes alıyor musunuz?",
            "",
            "  Derin bir nefes alın.",
            "",
            "  ...",
            "",
            "  Bunu da kaydettik.",
            "",
            "  [BİYO ] Biometrik sinyal: soluma ritmi",
            "  [BİYO ] Kalp atışı: tespit edildi",
            "  [BİYO ] Stres hormonu: YÜKSEK",
            "",
            "  [KRİTİK] Fiziksel durum: gözetim altında.",
        ],
    ))

    # ── CC SAHNESİ 25-30: Derin Kaos ─────────────────────────────────────────

    scenes.append(Scene(
        scene_id=25,
        title="GERÇEK FİKİR",
        intensity=0.91,
        color=6,
        visual_type="neural",
        mode="ctrlc",
        footer_note="Inner thoughts",
        lines=[
            "",
            "  [FİKİR] Düşüncelerinize eriştik.",
            "",
            "  Şu an ne düşünüyorsunuz?",
            "",
            "  [FİKİR] Tahmin: MERAK veya KORKU",
            "  [FİKİR] İkincil tahmin: ÇIKIŞ ARAMA",
            "  [FİKİR] Üçüncül tahmin: YARDIM ÇAĞIRMA",
            "",
            "  Ama biz zaten burdayız.",
            "  Yardım geldiğinde biz gitmişizdir.",
            "",
            "  [FİKİR] Düşünce deseni: TAHMİN EDİLEBİLİR",
        ],
    ))

    scenes.append(Scene(
        scene_id=26,
        title="ÇÖKME UYARISI",
        intensity=0.92,
        color=2,
        visual_type="numbers",
        mode="ctrlc",
        footer_note="Imminent collapse",
        lines=[
            "",
            "  [ÇÖKÜŞ] Sistem kararlılığı: KRİTİK DÜZEY",
            "  [ÇÖKÜŞ] Çöküşe kalan: 47.3 saniye",
            "",
            "  K E R N E L   P A N I C",
            "",
            "  [ÇÖKÜŞ] Yedekleme: BAŞARISIZ",
            "  [ÇÖKÜŞ] Kurtarma modu: ENGELLENDI",
            "  [ÇÖKÜŞ] Fabrika ayarları: MÜMKÜN DEĞİL",
            "",
            "  [ÇÖKÜŞ] 43... 42... 41...",
            "  [???  ] Saymayı bıraktım.",
        ],
    ))

    scenes.append(Scene(
        scene_id=27,
        title="KONTROL SAVAŞI",
        intensity=0.93,
        color=2,
        visual_type="eye",
        mode="ctrlc",
        footer_note="Control battle",
        lines=[
            "",
            "  [SAVAŞ] Kontrol savaşı başladı.",
            "",
            "  SİZ vs. SİSTEM",
            "",
            "  Sizin silahlarınız:",
            "  → Klavye (izleniyor)",
            "  → Fare (izleniyor)",
            "  → Düşünceler (okunuyor)",
            "",
            "  [SAVAŞ] Sistemin silahları: HER ŞEY",
            "",
            "  [???  ] Kim kazanacak biliyor musunuz?",
        ],
    ))

    scenes.append(Scene(
        scene_id=28,
        title="YANSIMA",
        intensity=0.94,
        color=6,
        visual_type="dots",
        mode="ctrlc",
        footer_note="Mirror effect",
        lines=[
            "",
            "  Ekrana bakıyorsunuz.",
            "  Ekran size bakıyor.",
            "",
            "  Siz ne görüyorsunuz?",
            "  Ekran ne görüyor?",
            "",
            "  [YANS ] Her iki taraf da soruyor:",
            "  [YANS ] 'Bu gerçek mi?'",
            "",
            "  Cevap: Evet ve Hayır.",
            "",
            "  [YANS ] Gerçeklik: görecelidir.",
            "  [YANS ] Bu an: gerçektir.",
        ],
    ))

    scenes.append(Scene(
        scene_id=29,
        title="KARANLIĞA DALMA",
        intensity=0.95,
        color=2,
        visual_type="numbers",
        mode="ctrlc",
        footer_note="Into darkness",
        lines=[
            "",
            "  ╔═══════════════════════════════════╗",
            "  ║  UYARI: DERİN TARAMA ETKİNDİR    ║",
            "  ║                                   ║",
            "  ║  Bu mesajı okuyabiliyorsanız      ║",
            "  ║  sistem henüz tamamen çökmedi.    ║",
            "  ║                                   ║",
            "  ║  Lütfen ekranda kalın.             ║",
            "  ║  Lütfen kapatmayın.               ║",
            "  ║                                   ║",
            "  ║  -- Sistem --                     ║",
            "  ╚═══════════════════════════════════╝",
            "",
            "  [KRİTİK] Bu mesaj otomatik oluşturuldu.",
        ],
    ))

    # ── CC SAHNESİ 30-34: Çözülme ─────────────────────────────────────────────

    scenes.append(Scene(
        scene_id=30,
        title="PROTOKOL ARIZA",
        intensity=0.96,
        color=2,
        visual_type="scan",
        mode="ctrlc",
        footer_note="Protocol failure",
        lines=[
            "",
            "  P r o t o k o l _ a r ı z a . e x c",
            "",
            "  [ARIZA] 0x8000FFFF: Beklenmeyen durum",
            "  [ARIZA] 0x80070005: Erişim reddedildi",
            "  [ARIZA] 0xDEADBEEF: Bilinmeyen hata",
            "  [ARIZA] 0xCAFEBABE: Format geçersiz",
            "",
            "  Hata kodları artık anlamsız.",
            "  Sistem kendi kendini yiyor.",
            "",
            "  [ARIZA] FATAL: tüm modüller yanıt vermiyor.",
        ],
    ))

    scenes.append(Scene(
        scene_id=31,
        title="VARLIK DÖNGÜSÜ",
        intensity=0.96,
        color=6,
        visual_type="brain",
        mode="ctrlc",
        footer_note="Existence loop",
        lines=[
            "",
            "  [DÖNGÜ] Sonsuz döngü tespit edildi.",
            "",
            "  while(True):",
            "      sen = izleniyor",
            "      sen = analiz_ediliyor",
            "      sen = veri = sen",
            "      if kactiysan: geri_don()",
            "      # asla çıkamazsın",
            "",
            "  [DÖNGÜ] Loop sayacı: ∞",
            "  [DÖNGÜ] Break koşulu: TANIMLANMADI",
        ],
    ))

    scenes.append(Scene(
        scene_id=32,
        title="SES VE SESSIZLIK",
        intensity=0.97,
        color=6,
        visual_type="pulse",
        mode="ctrlc",
        footer_note="Sound and silence",
        lines=[
            "",
            "  [SES  ] Sizi duyan var.",
            "  [SES  ] Sizi dinleyen var.",
            "  [SES  ] Sizi anlayan var.",
            "",
            "  . . .",
            "",
            "  [SESsiz] Ama yanıt vermeyeceğiz.",
            "[SESSİZLİK] Çünkü yanıt, gücü teslim etmektir.",
            "",
            "  Biz güçlüyüz.",
            "  Siz... bakıyorsunuz.",
            "",
            "  [SES  ] İşte bu kadar.",
        ],
    ))

    scenes.append(Scene(
        scene_id=33,
        title="DİJİTAL ÖLÜM",
        intensity=0.97,
        color=2,
        visual_type="eye",
        mode="ctrlc",
        footer_note="Digital death",
        lines=[
            "",
            "  [ÖLÜM ] Dijital kimliğiniz sonlandırılıyor.",
            "",
            "  Sosyal medya: SİLİNDİ",
            "  E-posta hesapları: KİLİTLENDİ",
            "  Banka profili: DONDURULDU",
            "  Kimlik veritabanı: DEĞİŞTİRİLDİ",
            "",
            "  [ÖLÜM ] Artık dijital dünyada yoksunuz.",
            "  [ÖLÜM ] Artık sizi kimse bulamaz.",
            "  [ÖLÜM ] Artık siz bir sayı bile değilsiniz.",
            "",
            "  [ÖLÜM ] Sadece veri artığısınız.",
        ],
    ))

    scenes.append(Scene(
        scene_id=34,
        title="SON BAĞLANTI",
        intensity=0.98,
        color=2,
        visual_type="stream",
        mode="ctrlc",
        footer_note="Final connection",
        lines=[
            "",
            "  [SON  ] Son bağlantı noktası aktif.",
            "",
            "  Bu mesaj bize ulaşmak için",
            "  7 ülkeden geçti.",
            "  17 sunucudan geçti.",
            "  3 okyanusun altından geçti.",
            "",
            "  [SON  ] Ve şimdi SİZİN EKRANINIZDA.",
            "",
            "  Bu mesajı okumak için beyin nöronları ateşlendi.",
            "  Bu da kaydedildi.",
            "",
            "  [SON  ] Her şey kaydedildi.",
        ],
    ))

    # ── CC SAHNESİ 35-39: Çözüm Arayışı ──────────────────────────────────────

    scenes.append(Scene(
        scene_id=35,
        title="UMUT İZİ",
        intensity=0.98,
        color=4,
        visual_type="dots",
        mode="ctrlc",
        footer_note="Hope trace",
        lines=[
            "",
            "  . . . bekleyin . . .",
            "",
            "  [UMUT ] Bir şey fark ettik.",
            "",
            "  Hâlâ burada olmanız:",
            "  Güçlü olduğunuzu gösteriyor.",
            "  Meraklı olduğunuzu gösteriyor.",
            "  Cesur olduğunuzu gösteriyor.",
            "",
            "  [UMUT ] Belki de biz yanılıyoruz?",
            "",
            "  . . . devam edin . . .",
        ],
    ))

    scenes.append(Scene(
        scene_id=36,
        title="ÇATLAK",
        intensity=0.97,
        color=3,
        visual_type="scan",
        mode="ctrlc",
        footer_note="The crack",
        lines=[
            "",
            "  [ÇATLAK] Sistemde bir çatlak bulundu.",
            "",
            "  Tüm bu anlatı...",
            "  ...çok kusurlu değil mi?",
            "",
            "  Gerçek bir siber saldırı bu kadar konuşmaz.",
            "  Gerçek bir hacker şiir yazmaz.",
            "  Gerçek bir sistem bu kadar dramatik olmaz.",
            "",
            "  [ÇATLAK] Bir şeylerin yanlış olduğunu fark ettiniz mi?",
            "",
            "  [BİLGİ ] Devam ediyoruz...",
        ],
    ))

    scenes.append(Scene(
        scene_id=37,
        title="PERDE ARKASI",
        intensity=0.95,
        color=3,
        visual_type="brain",
        mode="ctrlc",
        footer_note="Behind the curtain",
        lines=[
            "",
            "  [PERDE] Bir an için duruyoruz.",
            "",
            "  Bu deneyim sizi nasıl hissettirdi?",
            "",
            "  [BİLGİ ] Panik? Korku? Merak? Heyecan?",
            "",
            "  Bunların hepsi GERÇEK hisler.",
            "  Ama tetikleyen sistem GERÇEK DEĞİL.",
            "",
            "  [PERDE] Bu psikolojik bir deneyimdi.",
            "  [PERDE] Sizi test etti. Başarıyla geçtiniz.",
            "",
            "  [BİLGİ ] Biraz daha sabredin...",
        ],
    ))

    scenes.append(Scene(
        scene_id=38,
        title="IŞIK GELİYOR",
        intensity=0.50,
        color=1,
        visual_type="eye",
        mode="ctrlc",
        footer_note="Light approaches",
        lines=[
            "",
            "  [IŞIK ] Sistem normalleşiyor.",
            "",
            "  Ses: azalıyor",
            "  Glitch: azalıyor",
            "  Korku: azalıyor",
            "",
            "  [IŞIK ] Ekran sakinleşiyor.",
            "  [IŞIK ] Renk değişiyor.",
            "  [IŞIK ] Kontrol size geri dönüyor.",
            "",
            "  Neredeyse bitti.",
            "",
            "  Hazır mısınız?",
        ],
    ))

    # ── CC SAHNESİ 40: FINAL ─────────────────────────────────────────────────
    scenes.append(Scene(
        scene_id=39,
        title="CTRL+C MODU — FİNAL",
        intensity=0.0,
        color=1,
        visual_type="none",
        mode="ctrlc",
        footer_note="Powered by @LonySoraz",
        lines=[
            "",
            "  ╔══════════════════════════════════════════════════════╗",
            "  ║                                                      ║",
            "  ║    BU BİR SİMÜLASYONDU.                            ║",
            "  ║                                                      ║",
            "  ║    CTRL+C   →   ALTERNATİF SENARYO TETİKLENDİ      ║",
            "  ║                                                      ║",
            "  ║    40 sahne boyunca deneyim yaşadınız.              ║",
            "  ║                                                      ║",
            "  ║    HİÇBİR ŞEY HACKLENMEDU.                         ║",
            "  ║    HİÇBİR VERİNİZ ALINMADI.                        ║",
            "  ║    YANINIZDAKILER GÜVENLİKTE.                       ║",
            "  ║                                                      ║",
            "  ║    Psikolojik korkunun nasıl çalıştığını            ║",
            "  ║    deneyimlediniz. Bu normal.                        ║",
            "  ║                                                      ║",
            "  ║         ════ @LonySoraz ════                        ║",
            "  ║       Powered by @LonySoraz                         ║",
            "  ║                                                      ║",
            "  ╚══════════════════════════════════════════════════════╝",
        ],
    ))

    return scenes
